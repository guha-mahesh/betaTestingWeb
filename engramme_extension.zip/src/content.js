// content.js - Entry point for Engramme Assistant content script
// Orchestrates module initialization and callback wiring

// Create local aliases for frequently accessed namespace objects
const state = window.Engramme.state;
const utils = window.Engramme.utils;
const gmail = window.Engramme.gmail;
const overlay = window.Engramme.overlay;
const feedback = window.Engramme.feedback;
const chat = window.Engramme.chat;
const memoryDisplay = window.Engramme.memoryDisplay;
const openai = window.Engramme.openai;
const genericPage = window.Engramme.genericPage;
const memoryRefresh = window.Engramme.memoryRefresh;

console.log('🎯 Engramme Assistant content script loading...');

// Detect if we're on Gmail or a generic page
const isGmailPage = window.location.hostname.includes('mail.google.com');
const isBlockedDomain = window.location.hostname === 'app.engramme.com';
console.log(`📍 Context: ${isGmailPage ? 'Gmail' : 'Generic Web Page'}`);

// Check if an email view is already visible in the DOM (for Gmail reload detection)
function isEmailViewVisible() {
    const emailBody = document.querySelector('.ii.gt');
    const subjectElement = gmail.getThreadSubjectElement ? gmail.getThreadSubjectElement() : null;
    return !!(emailBody || subjectElement);
}

// Initialize API configuration state
function initializeMemories() {
    if (!utils.isExtensionValid()) return;

    console.log('📥 Checking API configuration...');

    try {
        chrome.storage.local.get(['apiConfigured'], (result) => {
            if (chrome.runtime.lastError) {
                console.error('❌ Storage error:', chrome.runtime.lastError);
                state.isApiConfigured = false;
            } else {
                state.isApiConfigured = result.apiConfigured || false;
                console.log(`✅ API configured: ${state.isApiConfigured}`);
            }
        });
    } catch (e) {
        console.error('💥 Extension context error:', e);
        state.isApiConfigured = false;
    }
}

// Set up message listener for extension communication
function setupMessageListener() {
    if (!utils.isExtensionValid()) return;

    try {
        chrome.runtime.onMessage.addListener((request) => {
            console.log('📨 Received message:', request);

            if (request.action === 'apiConfigured') {
                console.log('🔄 API configuration updated');
                initializeMemories();
                const effectiveMode = overlay.getEffectiveMode();
                if (effectiveMode === 'compose') {
                    memoryRefresh.updateForCompose();
                } else if (effectiveMode === 'view') {
                    memoryRefresh.updateForView();
                }
            }

            if (request.action === 'toggleDebug') {
                console.log('🐛 Debug toggle requested via keyboard shortcut');
                if (window.Engramme.debug) {
                    window.Engramme.debug.toggle();
                }
            }

        });
        console.log('📬 Message listener setup complete');
    } catch (e) {
        console.error('💥 Error setting up message listener:', e);
    }
}

// Cleanup resources on unload
function cleanup() {
    // Stop generic page monitoring
    genericPage.stopMonitoring();

    // Clean up input listeners
    state.inputListeners.forEach(({ element, type, listener }) => {
        try {
            element.removeEventListener(type, listener);
        } catch (e) {
            // Element might be removed from DOM
        }
    });
    state.inputListeners = [];

    // Remove UI elements
    if (state.overlayElement) {
        state.overlayElement.remove();
        state.overlayElement = null;
    }
    if (state.minimizeButton) {
        state.minimizeButton.remove();
        state.minimizeButton = null;
    }
    console.log('🧹 Cleanup complete');
}

// Main initialization function
function initialize() {
    console.log('🚀 Initializing Engramme Assistant...');

    if (isBlockedDomain) {
        console.log('⛔️ Engramme overlay disabled on engramme.com');
        cleanup();
        return;
    }

    cleanup();
    initializeMemories();
    setupMessageListener();

    // Create and show overlay immediately
    setTimeout(() => {
        if (!state.overlayElement) {
            overlay.create();
            overlay.show();
            
            // On Gmail, check if we're already viewing an email before showing empty state
            if (isGmailPage && isEmailViewVisible()) {
                // Email is already visible - show loading message and trigger memory search
                const memoryList = state.overlayElement.querySelector('.memory-list');
                if (memoryList) {
                    memoryList.innerHTML = '<div class="memories-loading">Searching memories...</div>';
                }
                // Trigger early email view detection
                gmail.checkForEmailView();
            } else {
                overlay.showEmptyState(isGmailPage);
            }
        }
    }, 1500);

    if (isGmailPage) {
        console.log('📧 Gmail context detected - starting Gmail observer');
        overlay.setupIntentListeners(isGmailPage);

        // Register callbacks for gmail module
        gmail.registerCallbacks({
            createOverlay: overlay.create,
            showOverlay: overlay.show,
            showEmptyState: () => overlay.showEmptyState(isGmailPage),
            clearAllFeedback: overlay.clearAllFeedback,
            updateMemorySuggestionsForView: memoryRefresh.updateForView,
            setActiveContext: overlay.setActiveContext,
            adjustOverlayPosition: overlay.adjustPosition,
            debouncedUpdateMemorySuggestions: memoryRefresh.debouncedUpdateForCompose
        });

        // Register callbacks for overlay module
        overlay.registerCallbacks({
            updateMemorySuggestions: memoryRefresh.updateForCompose,
            updateMemorySuggestionsForView: memoryRefresh.updateForView
        });

        // Register callbacks for feedback module
        feedback.registerCallbacks({
            getEffectiveMode: overlay.getEffectiveMode,
            showFeedback: overlay.showToast,
            dismissFeedback: overlay.dismissToast,
            isGmailPage: true
        });

        // Register callbacks for chat module
        chat.registerCallbacks({
            getEffectiveMode: overlay.getEffectiveMode,
            updateMemorySuggestions: memoryRefresh.updateForCompose,
            updateMemorySuggestionsForView: memoryRefresh.updateForView,
            showEmptyState: () => overlay.showEmptyState(isGmailPage)
        });

        // Register callbacks for memoryDisplay module
        memoryDisplay.registerCallbacks({
            showFeedbackButtons: overlay.showFeedbackButtons,
            getEffectiveMode: overlay.getEffectiveMode,
            insertMemory: openai.insertMemory,
            toggleMemoryCommentPanel: overlay.toggleMemoryCommentPanel,
            showFeedback: overlay.showToast,
            setupDetailViewScrollIndicator: overlay.setupDetailViewScrollIndicator
        });

        // Listen for URL changes (Gmail is a single-page app)
        let lastUrl = window.location.href;
        setInterval(() => {
            const currentUrl = window.location.href;
            if (currentUrl !== lastUrl) {
                lastUrl = currentUrl;
                console.log('🔗 URL changed, checking for email view...');
                setTimeout(gmail.checkForEmailView, 500);
            }
        }, 1000);

        setTimeout(() => {
            gmail.startObserver();
        }, 2000);
    } else {
        console.log('🌐 Generic page context detected - starting content monitoring');
        
        // Register callbacks for feedback module (generic pages)
        feedback.registerCallbacks({
            getEffectiveMode: overlay.getEffectiveMode,
            showFeedback: overlay.showToast,
            dismissFeedback: overlay.dismissToast,
            isGmailPage: false
        });

        // Register callbacks for overlay module (generic pages)
        overlay.registerCallbacks({
            updateMemorySuggestions: memoryRefresh.updateForCompose,
            updateMemorySuggestionsForView: memoryRefresh.updateForView
        });

        // Register callbacks for memoryDisplay module (generic pages)
        memoryDisplay.registerCallbacks({
            showFeedbackButtons: overlay.showFeedbackButtons,
            getEffectiveMode: overlay.getEffectiveMode,
            insertMemory: openai.insertMemory,
            toggleMemoryCommentPanel: overlay.toggleMemoryCommentPanel,
            showFeedback: overlay.showToast,
            setupDetailViewScrollIndicator: overlay.setupDetailViewScrollIndicator
        });

        // Register callbacks for chat module (generic pages)
        chat.registerCallbacks({
            getEffectiveMode: overlay.getEffectiveMode,
            updateMemorySuggestions: memoryRefresh.updateForCompose,
            updateMemorySuggestionsForView: memoryRefresh.updateForView,
            showEmptyState: () => overlay.showEmptyState(isGmailPage)
        });

        setTimeout(() => {
            genericPage.startMonitoring();
        }, 2000);
    }

    console.log('✅ Engramme Assistant initialized');
}

// Start initialization
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
} else {
    initialize();
}

window.addEventListener('unload', cleanup);

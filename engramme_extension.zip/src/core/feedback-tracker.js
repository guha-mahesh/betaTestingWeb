// feedback-tracker.js - Local feedback persistence tracker
// Mirrors iOS FeedbackTracker: tracks likes/dislikes per (memoryId + queryHash) pair
// Persists to chrome.storage.local across tabs and Chrome restarts
// Depends on: core/state.js

(function() {
    'use strict';

    const STORAGE_KEY = 'engramme_feedback_entries';
    const QUERY_PREVIEW_LENGTH = 50;

    const feedbackTracker = {};

    // In-memory cache (loaded from chrome.storage.local on init)
    let entries = [];
    let isLoaded = false;

    // ========================================
    // Hash (djb2) — for query dedup, not security
    // ========================================

    function djb2Hash(str) {
        const normalized = str.toLowerCase().trim();
        let hash = 5381;
        for (let i = 0; i < normalized.length; i++) {
            hash = ((hash << 5) + hash) + normalized.charCodeAt(i);
            hash = hash & hash; // 32-bit integer
        }
        return (hash >>> 0).toString(16).padStart(8, '0');
    }

    // ========================================
    // Persistence
    // ========================================

    feedbackTracker.load = function() {
        return new Promise((resolve) => {
            try {
                chrome.storage.local.get([STORAGE_KEY], (result) => {
                    if (chrome.runtime.lastError) {
                        console.error('📊 FeedbackTracker: storage read error', chrome.runtime.lastError);
                        entries = [];
                    } else {
                        entries = result[STORAGE_KEY] || [];
                    }
                    isLoaded = true;
                    console.log(`📊 FeedbackTracker: Loaded ${entries.length} entries (👍 ${feedbackTracker.totalLikes} / 👎 ${feedbackTracker.totalDislikes})`);
                    resolve();
                });
            } catch (e) {
                console.error('📊 FeedbackTracker: context error on load', e);
                entries = [];
                isLoaded = true;
                resolve();
            }
        });
    };

    function save() {
        return new Promise((resolve) => {
            try {
                chrome.storage.local.set({ [STORAGE_KEY]: entries }, () => {
                    if (chrome.runtime.lastError) {
                        console.error('📊 FeedbackTracker: storage write error', chrome.runtime.lastError);
                    }
                    resolve();
                });
            } catch (e) {
                console.error('📊 FeedbackTracker: context error on save', e);
                resolve();
            }
        });
    }

    // ========================================
    // Core API (mirrors iOS FeedbackTracker)
    // ========================================

    /**
     * Record feedback for a memory+query pair.
     * Same (memoryId, queryHash) updates in place — no double-counting.
     */
    feedbackTracker.recordFeedback = async function(memoryId, queryText, rating) {
        if (!memoryId || !queryText || (rating !== 1 && rating !== -1)) return;

        const queryHash = djb2Hash(queryText);
        const queryPreview = queryText.trim().substring(0, QUERY_PREVIEW_LENGTH);
        const timestamp = new Date().toISOString();

        const existingIndex = entries.findIndex(
            e => e.memoryId === memoryId && e.queryHash === queryHash
        );

        if (existingIndex !== -1) {
            entries[existingIndex].rating = rating;
            entries[existingIndex].timestamp = timestamp;
            entries[existingIndex].queryPreview = queryPreview;
            console.log(`📊 FeedbackTracker: Updated ${memoryId} → ${rating === 1 ? '👍' : '👎'}`);
        } else {
            entries.push({ memoryId, queryHash, queryPreview, rating, timestamp });
            console.log(`📊 FeedbackTracker: Added ${rating === 1 ? '👍' : '👎'} for ${memoryId}`);
        }

        await save();
        console.log(`📊 FeedbackTracker: Saved (👍 ${feedbackTracker.totalLikes} / 👎 ${feedbackTracker.totalDislikes} / 📝 ${entries.length} entries)`);
    };

    /**
     * Get the current rating for a memory+query pair.
     * @returns {number|null} 1, -1, or null
     */
    feedbackTracker.getRating = function(memoryId, queryText) {
        if (!memoryId || !queryText) return null;
        const queryHash = djb2Hash(queryText);
        const entry = entries.find(e => e.memoryId === memoryId && e.queryHash === queryHash);
        return entry ? entry.rating : null;
    };

    // Computed getters (no stored counters — avoids drift)
    Object.defineProperty(feedbackTracker, 'totalLikes', {
        get: () => entries.filter(e => e.rating === 1).length
    });

    Object.defineProperty(feedbackTracker, 'totalDislikes', {
        get: () => entries.filter(e => e.rating === -1).length
    });

    Object.defineProperty(feedbackTracker, 'totalFeedbackCount', {
        get: () => entries.length
    });

    Object.defineProperty(feedbackTracker, 'allEntries', {
        get: () => [...entries]
    });

    Object.defineProperty(feedbackTracker, 'isLoaded', {
        get: () => isLoaded
    });

    // Auto-load on init
    feedbackTracker.load();

    window.Engramme.feedbackTracker = feedbackTracker;
    console.log('📊 FeedbackTracker module loaded');
})();

// memory-recall.js - Memory recall API client with caching
// Handles API requests to fetch relevant memories based on context
// Depends on: core/state.js

(function() {
    'use strict';

    const api = {};
    const state = window.Engramme.state;
    const constants = window.Engramme.constants;

    /**
     * Get cached memories for a given cache key
     * @param {string} cacheKey - The cache key to look up
     * @returns {Object|null} Cached entry with memories, recallId, and fetchedAt, or null if not found/expired
     */
    api.getCachedMemories = function(cacheKey) {
        const entry = state.recallCache.get(cacheKey);
        if (!entry) return null;
        if (Date.now() - entry.fetchedAt > constants.REQUEST_CACHE_TTL_MS) {
            state.recallCache.delete(cacheKey);
            return null;
        }
        return entry;
    };

    /**
     * Cache memories for a given cache key
     * @param {string} cacheKey - The cache key to store under
     * @param {Array} memories - Array of memory objects to cache
     * @param {string|null} recallId - Recall context identifier from service worker
     */
    api.setCachedMemories = function(cacheKey, memories, recallId = null) {
        state.recallCache.set(cacheKey, { memories, recallId, fetchedAt: Date.now() });
    };

    /**
     * Start a new request and track it
     * @param {string} requestKey - Unique key for this request
     * @param {boolean} isMeaningfulChange - Whether this represents a meaningful query change
     * @returns {number} The request ID
     */
    api.startRequest = function(requestKey, isMeaningfulChange) {
        state.requestCounter += 1;
        const requestId = state.requestCounter;
        if (isMeaningfulChange) {
            state.latestEligibleRequestId = requestId;
            state.latestEligibleRequestKey = requestKey;
        }
        return requestId;
    };

    /**
     * Search for relevant memories via the API
     * @param {string} text - The text to search for relevant memories
     * @param {string[]} participantEmails - Array of participant email addresses for metadata filtering
     * @returns {Promise<{memories: Array, recallId: string|null, error: boolean}>} Search results
     */
    api.findRelevantMemories = async function(text, participantEmails = []) {
        console.log(`🔍 Searching for memories via API: "${text.substring(0, 100)}..."`);
        if (participantEmails.length > 0) {
            console.log(`📧 Including ${participantEmails.length} participant emails for metadata filtering`);
        }

        if (!state.isApiConfigured) {
            console.warn('⚠️ API not configured');
            return { memories: [], recallId: null, error: true };
        }

        // Store the payload for debug display (show first 1000 chars, matching background.js truncation)
        // Note: URL is dynamically determined by background.js based on selected environment
        state.lastRecallPayload = {
            url: '[Environment-specific URL determined by background.js]',
            method: 'POST',
            headers: {
                'x-api-key': '[HIDDEN]'
            },
            formData: {
                text: text.length > 1000 ? text.slice(0, 1000) : text,
                top_k: '3',
                ambience_metadata: participantEmails.length > 0 ? JSON.stringify({ participant_emails: participantEmails }) : undefined
            },
            textLength: text.length,
            timestamp: new Date().toISOString(),
            note: 'Actual URL depends on Developer Mode environment setting'
        };

        try {
            // Send message to background script to search memories
            const response = await chrome.runtime.sendMessage({
                action: 'searchMemories',
                text: text,
                participantEmails: participantEmails
            });

            if (response.success) {
                console.log(`✅ Found ${response.memories.length} memories from API`);
                state.lastRecallTrace = response.trace || null;
                // Update payload with confirmed data from background.js (what was actually sent)
                if (response.confirmedPayload) {
                    state.lastRecallPayload = {
                        url: response.confirmedPayload.url,
                        method: response.confirmedPayload.method,
                        headers: { 'x-api-key': '[HIDDEN]' },
                        formData: {
                            text: response.confirmedPayload.text,
                            top_k: response.confirmedPayload.top_k,
                            ambience_metadata: response.confirmedPayload.ambience_metadata
                        },
                        textLength: response.confirmedPayload.textLength,
                        participant_emails: response.confirmedPayload.participant_emails,
                        timestamp: response.confirmedPayload.timestamp,
                        confirmed: true  // Flag indicating this is confirmed sent data
                    };
                }
                return { memories: response.memories || [], recallId: response.recallId || null, error: false };
            }
            console.error('❌ Memory search failed:', response.error);
            return { memories: [], recallId: null, error: true };
        } catch (error) {
            console.error('❌ Error calling memory search:', error);
            return { memories: [], recallId: null, error: true };
        }
    };

    // Export api to namespace
    window.Engramme.api = api;

    console.log('✅ Engramme API loaded');
})();

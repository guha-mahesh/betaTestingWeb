// memory-refresh.js - Memory refresh orchestration
// Coordinates when and how to update memory suggestions across different contexts

(function() {
    'use strict';

    const state = window.Engramme.state;
    const utils = window.Engramme.utils;
    const api = window.Engramme.api;
    const gmail = window.Engramme.gmail;
    const overlay = window.Engramme.overlay;
    const feedback = window.Engramme.feedback;
    const memoryDisplay = window.Engramme.memoryDisplay;

    // Check if display should proceed based on eligibility criteria
    function displayMemoriesIfEligible(relevantMemories, mode, queryText, requestId, requestKey, normalizedQuery, isMeaningfulChange, baselineMode = mode) {
        if (feedback.hasTypedFeedback()) {
            console.log('⏸️ Skipping display - typed feedback present');
            return;
        }
        const isEligible = isMeaningfulChange || relevantMemories.length > 0;
        if (!isEligible) {
            console.log('⏭️ Skipping display - empty results below threshold');
            return;
        }
        if (requestId < state.latestEligibleRequestId) {
            console.log('⏭️ Skipping stale memories response');
            return;
        }
        state.latestEligibleRequestId = requestId;
        state.latestEligibleRequestKey = requestKey;
        const previousQuery = state.lastDisplayedQueryByMode[baselineMode] || '';
        if (normalizedQuery !== previousQuery) {
            console.log('🧽 Clearing feedback due to query change');
            overlay.clearAllFeedback();
        }
        memoryDisplay.display(relevantMemories, mode, queryText);
        utils.markDisplayedQuery(baselineMode, normalizedQuery);
    }

    // Update memory suggestions for compose mode (Gmail)
    async function updateForCompose() {
        if (!state.currentComposeElement || !state.overlayElement) {
            console.log('⚠️ No compose element or overlay found');
            return;
        }

        if (state.activeContext && state.activeContext !== 'compose') {
            console.log('⏭️ Skipping compose refresh - active context is view');
            return;
        }

        // Don't refresh memories when chat is open (prevents destroying chat UI)
        if (state.isChatMode) {
            console.log('💬 Chat is open, skipping memory refresh');
            return;
        }

        const emailContent = gmail.getEmailContent();
        const baseText = [
            emailContent.subject ? `sb: ${emailContent.subject}` : '',
            emailContent.body
        ].filter(Boolean).join('\n').trim();
        const extraParts = [];
        if (emailContent.from) {
            extraParts.push(`From: ${emailContent.from}`);
        }
        if (emailContent.to && emailContent.to.length > 0) {
            extraParts.push(`To: ${emailContent.to.join(', ')}`);
        }
        if (emailContent.cc && emailContent.cc.length > 0) {
            extraParts.push(`Cc: ${emailContent.cc.join(', ')}`);
        }
        if (emailContent.bcc && emailContent.bcc.length > 0) {
            extraParts.push(`Bcc: ${emailContent.bcc.join(', ')}`);
        }
        if (emailContent.time) {
            extraParts.push(`Time: ${emailContent.time}`);
        }
        const queryText = [...extraParts, baseText].filter(Boolean).join('\n').trim();

        console.log('📧 Email content:', {
            subject: emailContent.subject,
            bodyLength: emailContent.body.length,
            combinedLength: queryText.length
        });

        if (baseText.length <= 50) {
            const memoryList = state.overlayElement.querySelector('.memory-list');
            memoryList.innerHTML = '<div class="memories-loading">Type 50+ characters to see memories...</div>';
            console.log('📏 Text too short, showing loading message');
            overlay.hideFeedbackButtons();
            overlay.clearQueryText();
            return;
        }

        if (!state.isApiConfigured) {
            overlay.showNotLoggedIn();
            overlay.hideFeedbackButtons();
            overlay.clearQueryText();
            return;
        }

        const diffInfo = utils.evaluateQueryChange('compose', queryText);
        if (diffInfo.isSameQuery) {
            console.log('⏭️ Skipping refresh - query unchanged');
            return;
        }
        if (!diffInfo.isMeaningfulChange) {
            console.log(`↪️ Diff below threshold (${Math.round(diffInfo.diffScore * 100)}%), requesting without empty-state update`);
        }

        const normalizedQuery = diffInfo.normalized;
        const requestKey = utils.getRequestKey('compose', normalizedQuery);
        const requestId = api.startRequest(requestKey, diffInfo.isMeaningfulChange);
        const cacheKey = utils.getRecallCacheKey(normalizedQuery);
        const cached = api.getCachedMemories(cacheKey);
        if (cached) {
            const cachedAgeMs = Date.now() - cached.fetchedAt;
            console.log(`🗄️ Cache hit for memories (${Math.round(cachedAgeMs / 1000)}s old)`);
            displayMemoriesIfEligible(cached.memories, 'compose', queryText, requestId, requestKey, normalizedQuery, diffInfo.isMeaningfulChange);
            return;
        }

        const composeState = state.requestState.compose;
        if (composeState.inFlight) {
            composeState.needsRefresh = true;
            console.log('⏭️ Compose request in flight, scheduling refresh');
            return;
        }

        if (diffInfo.isMeaningfulChange) {
            const memoryList = state.overlayElement.querySelector('.memory-list');
            memoryList.innerHTML = '<div class="memories-loading">Searching memories...</div>';
            overlay.hideFeedbackButtons();
        }

        composeState.inFlight = true;
        try {
            const recallResult = await api.findRelevantMemories(normalizedQuery);
            if (!recallResult.error) {
                api.setCachedMemories(cacheKey, recallResult.memories);
            }
            displayMemoriesIfEligible(recallResult.memories, 'compose', queryText, requestId, requestKey, normalizedQuery, diffInfo.isMeaningfulChange);
        } finally {
            composeState.inFlight = false;
            if (composeState.needsRefresh) {
                composeState.needsRefresh = false;
                updateForCompose();
            }
        }
    }

    // Update memory suggestions for view mode (Gmail email reading)
    async function updateForView() {
        if (!state.overlayElement) {
            console.log('⚠️ No overlay element found');
            return;
        }
        
        // Try to find view element if not already set
        if (!state.currentViewElement) {
            const viewElement = document.querySelector('.ii.gt, .a3s.aiL, .gE.iv.gt');
            if (viewElement) {
                state.currentViewElement = viewElement;
                console.log('📧 Found view element dynamically');
            } else {
                console.log('⚠️ No view element found');
                return;
            }
        }

        if (state.activeContext && state.activeContext !== 'view') {
            console.log('⏭️ Skipping view refresh - active context is compose');
            return;
        }

        // Don't refresh memories when chat is open (prevents destroying chat UI)
        if (state.isChatMode) {
            console.log('💬 Chat is open, skipping memory refresh');
            return;
        }

        const emailContent = gmail.getViewedEmailContent();
        const extraParts = [];
        if (emailContent.recipients && emailContent.recipients.length > 0) {
            // Recipients already appear in labeled headers; avoid duplicate list.
        }
        const queryText = [
            ...extraParts,
            emailContent.subject ? `sb: ${emailContent.subject}` : '',
            emailContent.body
        ].filter(Boolean).join('\n').trim();

        console.log('📖 Viewed email content:', {
            subject: emailContent.subject,
            bodyLength: emailContent.body.length,
            combinedLength: queryText.length
        });

        if (!state.isApiConfigured) {
            overlay.showNotLoggedIn();
            overlay.hideFeedbackButtons();
            overlay.clearQueryText();
            return;
        }

        const diffInfo = utils.evaluateQueryChange('view', queryText);
        if (diffInfo.isSameQuery) {
            console.log('⏭️ Skipping refresh - query unchanged');
            return;
        }
        if (!diffInfo.isMeaningfulChange) {
            console.log(`↪️ Diff below threshold (${Math.round(diffInfo.diffScore * 100)}%), requesting without empty-state update`);
        }

        const normalizedQuery = diffInfo.normalized;
        const requestKey = utils.getRequestKey('view', normalizedQuery);
        const requestId = api.startRequest(requestKey, diffInfo.isMeaningfulChange);
        const cacheKey = utils.getRecallCacheKey(normalizedQuery);
        const cached = api.getCachedMemories(cacheKey);
        if (cached) {
            const cachedAgeMs = Date.now() - cached.fetchedAt;
            console.log(`🗄️ Cache hit for memories (${Math.round(cachedAgeMs / 1000)}s old)`);
            displayMemoriesIfEligible(cached.memories, 'view', queryText, requestId, requestKey, normalizedQuery, diffInfo.isMeaningfulChange);
            return;
        }

        const viewState = state.requestState.view;
        if (viewState.inFlight) {
            viewState.needsRefresh = true;
            console.log('⏭️ View request in flight, scheduling refresh');
            return;
        }

        if (diffInfo.isMeaningfulChange) {
            const memoryList = state.overlayElement.querySelector('.memory-list');
            memoryList.innerHTML = '<div class="memories-loading">Searching memories...</div>';
            overlay.hideFeedbackButtons();
        }

        viewState.inFlight = true;
        try {
            const recallResult = await api.findRelevantMemories(normalizedQuery);
            if (!recallResult.error) {
                api.setCachedMemories(cacheKey, recallResult.memories);
            }
            displayMemoriesIfEligible(recallResult.memories, 'view', queryText, requestId, requestKey, normalizedQuery, diffInfo.isMeaningfulChange);
        } finally {
            viewState.inFlight = false;
            if (viewState.needsRefresh) {
                viewState.needsRefresh = false;
                updateForView();
            }
        }
    }

    // Module-level debounce timer for generic page updates
    let genericDebounceTimer = null;

    // Update memory suggestions for generic (non-Gmail) pages
    function updateForGenericPage() {
        if (!state.overlayElement) return;

        // Clear existing debounce timer
        if (genericDebounceTimer) {
            clearTimeout(genericDebounceTimer);
        }

        // Debounce the update to avoid excessive API calls
        genericDebounceTimer = setTimeout(async () => {
            const extractors = window.Engramme.extractors;
            const pageContent = extractors.getGenericPageContent();
            const queryText = pageContent.trim();

            console.log('📄 Page content length:', pageContent.length);
            console.log('📄 Page content preview:', pageContent.substring(0, 200));
            console.log('🌐 Current URL:', window.location.href);

            const memoryList = state.overlayElement.querySelector('.memory-list');
            if (!memoryList) return;

            if (window.location.hostname === 'google.com' || window.location.hostname === 'www.google.com') {
                const queryParam = new URLSearchParams(window.location.search).get('q');
                if (!queryParam) {
                    memoryList.innerHTML = '<div class="no-memories">Make a search to see memories.</div>';
                    overlay.clearQueryText();
                    return;
                }
            }

            if (!state.isApiConfigured) {
                overlay.showNotLoggedIn();
                overlay.clearQueryText();
                return;
            }

            // Lowered from 50 to 10 chars - let API decide what's useful
            if (queryText.length < 10) {
                console.log('⚠️ Content too short:', queryText.length, 'chars');
                memoryList.innerHTML = '<div class="no-memories">Not enough content on this page to find relevant memories.</div>';
                overlay.clearQueryText();
                return;
            }

            const diffInfo = utils.evaluateQueryChange('generic', queryText);
            if (diffInfo.isSameQuery) {
                console.log('⏭️ Skipping refresh - query unchanged');
                return;
            }
            if (!diffInfo.isMeaningfulChange) {
                console.log(`↪️ Diff below threshold (${Math.round(diffInfo.diffScore * 100)}%), requesting without empty-state update`);
            }

            const normalizedQuery = diffInfo.normalized;
            const requestKey = utils.getRequestKey('generic', normalizedQuery);
            const requestId = api.startRequest(requestKey, diffInfo.isMeaningfulChange);
            const cacheKey = utils.getRecallCacheKey(normalizedQuery);
            const cached = api.getCachedMemories(cacheKey);
            if (cached) {
                const cachedAgeMs = Date.now() - cached.fetchedAt;
                console.log(`🗄️ Cache hit for memories (${Math.round(cachedAgeMs / 1000)}s old)`);
                displayMemoriesIfEligible(cached.memories, 'compose', queryText, requestId, requestKey, normalizedQuery, diffInfo.isMeaningfulChange, 'generic');
                return;
            }

            const genericState = state.requestState.generic;
            if (genericState.inFlight) {
                genericState.needsRefresh = true;
                console.log('⏭️ Generic request in flight, scheduling refresh');
                return;
            }

            if (diffInfo.isMeaningfulChange) {
                memoryList.innerHTML = '<div class="memories-loading">Searching for relevant memories...</div>';
            }

            genericState.inFlight = true;
            try {
                const recallResult = await api.findRelevantMemories(normalizedQuery);
                if (!recallResult.error) {
                    api.setCachedMemories(cacheKey, recallResult.memories);
                }
                displayMemoriesIfEligible(recallResult.memories, 'compose', queryText, requestId, requestKey, normalizedQuery, diffInfo.isMeaningfulChange, 'generic');
            } finally {
                genericState.inFlight = false;
                if (genericState.needsRefresh) {
                    genericState.needsRefresh = false;
                    updateForGenericPage();
                }
            }
        }, 1000); // 1000ms debounce delay to reduce API calls
    }

    // Update memory suggestions with custom text (e.g., Meet transcripts)
    async function updateWithCustomText(customText) {
        if (!state.overlayElement) return;
        if (!customText || !customText.trim()) {
            console.log('⚠️ Custom text empty, skipping refresh');
            return;
        }

        const queryText = customText.trim();
        const normalizedQuery = utils.normalizeQueryText(queryText);
        const requestKey = utils.getRequestKey('generic', normalizedQuery);
        const requestId = api.startRequest(requestKey, true);

        const memoryList = state.overlayElement.querySelector('.memory-list');
        if (!state.isApiConfigured) {
            if (memoryList) {
                memoryList.innerHTML = '<div class="no-memories">API key not configured.<br><br>Please configure your API key in the extension settings.</div>';
            }
            overlay.clearQueryText();
            return;
        }

        if (memoryList) {
            memoryList.innerHTML = '<div class="memories-loading">Searching for relevant memories...</div>';
        }

        const genericState = state.requestState.generic;
        if (genericState.inFlight) {
            genericState.needsRefresh = true;
            console.log('⏭️ Custom request in flight, scheduling refresh');
            return;
        }

        genericState.inFlight = true;
        try {
            const recallResult = await api.findRelevantMemories(normalizedQuery);
            displayMemoriesIfEligible(
                recallResult.memories,
                'compose',
                queryText,
                requestId,
                requestKey,
                normalizedQuery,
                true,
                'generic'
            );
        } finally {
            genericState.inFlight = false;
            if (genericState.needsRefresh) {
                genericState.needsRefresh = false;
                updateWithCustomText(customText);
            }
        }
    }

    // Create debounced versions using shared utility
    const debouncedUpdateForCompose = utils.debounce(updateForCompose, 300);
    const debouncedUpdateForView = utils.debounce(updateForView, 300);

    // Expose to namespace
    window.Engramme.memoryRefresh = {
        updateForCompose,
        updateForView,
        updateForGenericPage,
        updateWithCustomText,
        debouncedUpdateForCompose,
        debouncedUpdateForView,
        displayMemoriesIfEligible
    };

    console.log('✅ Engramme memory-refresh module loaded');
})();

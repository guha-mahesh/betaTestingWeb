// monitor.js - Page content monitoring and memorization
// Watches for content changes on non-Gmail pages and triggers memory updates

(function() {
    'use strict';

    const state = window.Engramme.state;
    const utils = window.Engramme.utils;

    // Module-level state
    let lastPageContent = '';
    let checkInterval = null;
    let scrollTimeout = null;
    let scrollHandler = null;
    let isScrollListenerAttached = false;

    // Extract FULL page content for memorization (no truncation)
    // Routes to specialized extractors when available
    function getFullContent() {
        try {
            const hostname = window.location.hostname;

            // Route to specialized extractors first
            // SF Chronicle - use dedicated extractor
            if (hostname.includes('sfchronicle.com')) {
                const sfchronicle = window.Engramme?.sfchronicle;
                if (sfchronicle && sfchronicle.shouldExtract()) {
                    console.log('📰 Monitor: Using SF Chronicle specialized extractor for memorization');
                    const sfcContent = sfchronicle.getContent(false); // Get all content, not just viewport
                    if (sfcContent && sfcContent.length > 0) {
                        return sfcContent;
                    }
                }
            }

            // Google Search - use dedicated extractor
            if (hostname.includes('google.com')) {
                const googleSearch = window.Engramme?.googleSearch;
                if (googleSearch && googleSearch.shouldExtract()) {
                    console.log('🔍 Monitor: Using Google Search specialized extractor for memorization');
                    const searchContent = googleSearch.getContent();
                    if (searchContent && searchContent.length > 0) {
                        return searchContent;
                    }
                }
            }

            // Use extractors module if available for other sites
            const extractors = window.Engramme?.extractors;
            if (extractors && extractors.getGenericPageContent) {
                const extractedContent = extractors.getGenericPageContent();
                if (extractedContent && extractedContent.length > 100) {
                    return extractedContent;
                }
            }

            // Generic fallback for sites without specialized extractors
            let fullText = '';

            // Get page title
            if (document.title) {
                fullText += document.title + '\n\n';
            }

            // Get URL
            fullText += `URL: ${window.location.href}\n\n`;

            // Get meta description
            const metaDesc = document.querySelector('meta[name="description"]');
            if (metaDesc && metaDesc.content) {
                fullText += metaDesc.content + '\n\n';
            }

            // Main content extraction strategies
            const mainSelectors = [
                'main',
                'article',
                '[role="main"]',
                '#content',
                '.content',
                '#main',
                '.main',
                '.post',
                '.entry-content',
                '.article-body',
                '.story-body'
            ];

            for (const selector of mainSelectors) {
                const elements = document.querySelectorAll(selector);
                elements.forEach(el => {
                    if (el && el.textContent) {
                        fullText += el.textContent + '\n';
                    }
                });
            }

            // If no main content found, get all meaningful text
            if (fullText.length < 200) {
                // Get headings
                const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
                headings.forEach(h => {
                    if (h.textContent) fullText += h.textContent + '\n';
                });

                // Get paragraphs
                const paragraphs = document.querySelectorAll('p');
                paragraphs.forEach(p => {
                    if (p.textContent && p.textContent.length > 20) {
                        fullText += p.textContent + '\n';
                    }
                });

                // Get list items
                const listItems = document.querySelectorAll('li');
                listItems.forEach(li => {
                    if (li.textContent && li.textContent.length > 20) {
                        fullText += li.textContent + '\n';
                    }
                });
            }

            // Clean up the text but preserve structure
            fullText = fullText
                .replace(/\s+/g, ' ')  // Replace multiple spaces with single space
                .replace(/\n\s+/g, '\n')  // Clean up newlines
                .trim();

            return fullText;
        } catch (e) {
            console.error('❌ Error getting full generic page content:', e);
            return '';
        }
    }

    // Memorize page content by sending to background script
    async function memorize() {
        console.log('🎯 memorizeGenericPageContent() called');

        if (!utils.isExtensionValid()) {
            console.log('⚠️ Extension invalid, skipping memorization');
            return;
        }

        // Skip auto-memorization on Gmail and Google Docs
        const hostname = window.location.hostname;
        if (hostname === 'app.engramme.com') {
            console.log('⛔️ Skipping auto-memorization on app.engramme.com');
            return;
        }
        if (hostname.includes('mail.google.com') ||
            hostname.includes('gmail.com') ||
            hostname.includes('docs.google.com')) {
            console.log('⏭️ Skipping auto-memorization on Gmail/Google Docs:', hostname);
            return;
        }
        if (hostname === 'google.com' || hostname === 'www.google.com') {
            const queryParam = new URLSearchParams(window.location.search).get('q');
            if (!queryParam) {
                console.log('⏭️ Skipping auto-memorization on Google homepage');
                return;
            }
        }

        console.log('🔍 Checking state.isApiConfigured:', state.isApiConfigured);
        if (!state.isApiConfigured) {
            console.log('⚠️ API not configured, skipping memorization');
            return;
        }

        try {
            console.log('📄 Extracting full page content...');
            const fullContent = getFullContent();
            console.log('📄 Extracted content length:', fullContent.length);
            console.log('📄 Content preview:', fullContent.substring(0, 200));

            if (fullContent.trim().length < 100) {
                console.log('⚠️ Not enough content to memorize (< 100 chars), actual:', fullContent.trim().length);
                return;
            }

            console.log('💾 Memorizing page content...', {
                url: window.location.href,
                contentLength: fullContent.length
            });

            const response = await chrome.runtime.sendMessage({
                action: 'memorizeContent',
                text: fullContent,
                url: window.location.href
            });

            if (response.success) {
                console.log('✅ Page content memorized successfully');
            } else {
                console.error('❌ Failed to memorize content:', response.error);
            }
        } catch (error) {
            console.error('❌ Error memorizing page content:', error);
        }
    }

    // Check if refresh should be blocked due to active user interaction
    function shouldBlockRefresh() {
        if (!state.overlayElement) return false;

        // 1. Block if in detailed view
        const detailView = state.overlayElement.querySelector('.memory-detail-view');
        if (detailView) {
            console.log('🚫 Blocking refresh: in detailed view');
            return true;
        }

        // 2. Block if chat mode is active
        if (state.isChatMode) {
            console.log('🚫 Blocking refresh: chat mode active');
            return true;
        }

        // 3. Block if any comment panel is open
        const openCommentPanels = state.overlayElement.querySelectorAll('.memory-comment-panel.show');
        if (openCommentPanels && openCommentPanels.length > 0) {
            console.log('🚫 Blocking refresh: comment panel open');
            return true;
        }

        return false;
    }

    function scheduleDebouncedRefresh(getMemoryRefresh) {
        if (scrollTimeout) {
            clearTimeout(scrollTimeout);
        }

        scrollTimeout = setTimeout(() => {
            if (shouldBlockRefresh()) {
                console.log('⏸️ Blocking refresh - user is actively interacting');
                return;
            }

            const extractors = window.Engramme.extractors;
            const currentContent = extractors.getGenericPageContent();
            if (currentContent !== lastPageContent && currentContent.length > 50) {
                lastPageContent = currentContent;
                console.log('📝 Page content changed (scroll pause)');

                memorize();

                const memoryRefresh = getMemoryRefresh();
                if (memoryRefresh) {
                    memoryRefresh.updateForGenericPage();
                }
            }
        }, 3000);
    }

    // Start monitoring generic page for content changes
    function startMonitoring() {
        // Skip monitoring on Google Meet - it has its own 1-minute timer in google-meets.js
        if (window.location.hostname === 'meet.google.com') {
            console.log('⏭️ Skipping generic page monitoring on Google Meet (uses own 1-minute timer)');
            return;
        }

        if (window.location.hostname === 'app.engramme.com') {
            console.log('⛔️ Skipping generic monitoring on app.engramme.com');
            return;
        }
        console.log('👁️ Starting generic page content monitoring...');
        console.log('🔍 Current state.isApiConfigured state:', state.isApiConfigured);

        // Get memoryRefresh module (loaded after this module)
        const getMemoryRefresh = () => window.Engramme.memoryRefresh;

        // Initial memorization after 1 second
        setTimeout(() => {
            console.log('⏰ 1-second timer fired, calling memorizeGenericPageContent()');
            console.log('🔍 state.isApiConfigured at memorization time:', state.isApiConfigured);
            memorize();
            const memoryRefresh = getMemoryRefresh();
            if (memoryRefresh) {
                memoryRefresh.updateForGenericPage();
            }
        }, 1000);

        if (isScrollListenerAttached) {
            return;
        }

        scrollHandler = () => scheduleDebouncedRefresh(getMemoryRefresh);
        window.addEventListener('scroll', scrollHandler, { passive: true });
        isScrollListenerAttached = true;
    }

    // Stop monitoring (for cleanup)
    function stopMonitoring() {
        if (checkInterval) {
            clearInterval(checkInterval);
            checkInterval = null;
        }

        if (scrollHandler) {
            window.removeEventListener('scroll', scrollHandler);
            scrollHandler = null;
            isScrollListenerAttached = false;
        }

        if (scrollTimeout) {
            clearTimeout(scrollTimeout);
            scrollTimeout = null;
        }
    }

    // Get check interval for cleanup
    function getCheckInterval() {
        return checkInterval;
    }

    // Expose to namespace
    window.Engramme.genericPage = {
        getFullContent,
        memorize,
        startMonitoring,
        stopMonitoring,
        shouldBlockRefresh,
        getCheckInterval
    };

    console.log('✅ Engramme generic-page module loaded');
})();

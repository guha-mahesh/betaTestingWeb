// overlay.js - Main overlay panel UI management
// Creates, positions, and controls the sidebar overlay panel
// Depends on: core/state.js, extraction/gmail.js, ui/feedback.js, ui/chat.js

(function() {
    'use strict';

    const overlay = {};
    const state = window.Engramme.state;
    const gmail = window.Engramme.gmail;
    const feedback = window.Engramme.feedback;
    const chat = window.Engramme.chat;

    // Callbacks for functions defined in content.js
    overlay.callbacks = {
        updateMemorySuggestions: null,
        updateMemorySuggestionsForView: null
    };

    /**
     * Register callbacks from content.js
     * @param {Object} callbacks - Object with callback functions
     */
    overlay.registerCallbacks = function(callbacks) {
        Object.assign(overlay.callbacks, callbacks);
    };

    /**
     * Adjust overlay position (delegates to gmail.adjustLayout)
     */
    overlay.adjustPosition = function() {
        gmail.adjustLayout(true);
        console.log(`📐 Overlay positioned as right sidebar for ${state.currentMode} mode`);
    };

    /**
     * Get the effective mode (activeContext or currentMode)
     * @returns {string} The effective mode
     */
    overlay.getEffectiveMode = function() {
        return state.activeContext || state.currentMode;
    };

    /**
     * Check if target is within compose window
     * @param {Element} target - DOM element to check
     * @returns {boolean}
     */
    overlay.isWithinCompose = function(target) {
        if (!state.currentComposeElement || !target) return false;
        return state.currentComposeElement === target || state.currentComposeElement.contains(target);
    };

    /**
     * Check if target is a compose header interaction (minimize, etc.)
     * @param {Element} target - DOM element to check
     * @returns {boolean}
     */
    overlay.isComposeHeaderInteraction = function(target) {
        if (!state.currentComposeElement || !target || !target.closest) return false;

        const minimizeSelectors = [
            '[aria-label*="Minimize"]', '[aria-label*="minimize"]',
            '[aria-label*="Minimise"]', '[aria-label*="minimise"]',
            '[data-tooltip*="Minimize"]', '[data-tooltip*="minimize"]',
            '[data-tooltip*="Minimise"]', '[data-tooltip*="minimise"]',
            '[title*="Minimize"]', '[title*="minimize"]',
            '[title*="Minimise"]', '[title*="minimise"]'
        ];
        if (target.closest(minimizeSelectors.join(','))) {
            return true;
        }

        const headerSelectors = [
            '[role="heading"]',
            '[aria-label*="New Message"]', '[aria-label*="New message"]',
            '.Hp', '.a3E', '.aYF'
        ];
        const header = state.currentComposeElement.querySelector(headerSelectors.join(','));
        return !!(header && header.contains(target));
    };

    /**
     * Check if there's a view context available
     * @returns {boolean}
     */
    overlay.hasViewContext = function() {
        if (state.currentViewElement) return true;
        return !!document.querySelector('.ii.gt, .a3s.aiL, h2[data-legacy-thread-id], .gE.iv.gt');
    };

    /**
     * Check if target is within email view
     * @param {Element} target - DOM element to check
     * @returns {boolean}
     */
    overlay.isWithinView = function(target) {
        if (!target) return false;

        if (state.currentViewElement && (state.currentViewElement === target || state.currentViewElement.contains(target))) {
            return true;
        }

        if (!target.closest) return false;

        const viewSelectors = [
            '.ii.gt', '.a3s.aiL', '.nH .aHU .hP',
            'h2[data-legacy-thread-id]', '.gE.iv.gt', '.zA'
        ];
        return !!target.closest(viewSelectors.join(','));
    };

    /**
     * Set active context
     * @param {string} nextContext - 'compose' or 'view'
     * @param {string} reason - Reason for context change
     */
    overlay.setActiveContext = function(nextContext, reason = '') {
        if (!nextContext || nextContext === state.activeContext) return;

        state.activeContext = nextContext;
        console.log(`🎯 Active context set to ${nextContext}${reason ? ` (${reason})` : ''}`);

        if (nextContext === 'compose' && overlay.callbacks.updateMemorySuggestions) {
            overlay.callbacks.updateMemorySuggestions();
        } else if (nextContext === 'view' && overlay.callbacks.updateMemorySuggestionsForView) {
            overlay.callbacks.updateMemorySuggestionsForView();
        }
    };

    /**
     * Setup intent listeners for Gmail compose/view context switching
     * @param {boolean} isGmailPage - Whether current page is Gmail
     */
    overlay.setupIntentListeners = function(isGmailPage) {
        if (state.intentListenersAttached || !isGmailPage) return;
        state.intentListenersAttached = true;

        const handleInteraction = (event) => {
            if (!event || !event.target) return;
            if (state.overlayElement && state.overlayElement.contains(event.target)) return;

            if (overlay.isWithinCompose(event.target)) {
                if (overlay.isComposeHeaderInteraction(event.target)) {
                    if (overlay.hasViewContext()) {
                        overlay.setActiveContext('view', 'compose-titlebar');
                    }
                    return;
                }
                overlay.setActiveContext('compose', 'interaction');
            } else if (overlay.isWithinView(event.target)) {
                overlay.setActiveContext('view', 'interaction');
            }
        };

        document.addEventListener('mousedown', handleInteraction, true);
        document.addEventListener('focusin', handleInteraction, true);
        document.addEventListener('keydown', handleInteraction, true);
    };

    /**
     * Setup scroll indicator for memory list
     */
    overlay.setupScrollIndicator = function() {
        const memoryList = document.querySelector('.memory-list');
        if (!memoryList) return;

        let scrollTimeout;

        memoryList.addEventListener('scroll', () => {
            const hasMoreContent = memoryList.scrollHeight > memoryList.clientHeight + memoryList.scrollTop + 10;

            if (hasMoreContent) {
                memoryList.classList.add('scrolling');
                clearTimeout(scrollTimeout);
                scrollTimeout = setTimeout(() => {
                    memoryList.classList.remove('scrolling');
                }, 1000);
            }
        });
    };

    /**
     * Setup scroll indicator for detail view
     */
    overlay.setupDetailViewScrollIndicator = function() {
        const detailView = document.querySelector('.memory-detail-view');
        if (!detailView) return;

        let scrollTimeout;

        detailView.addEventListener('scroll', () => {
            const hasMoreContent = detailView.scrollHeight > detailView.clientHeight + detailView.scrollTop + 10;

            if (hasMoreContent) {
                detailView.classList.add('scrolling');
                clearTimeout(scrollTimeout);
                scrollTimeout = setTimeout(() => {
                    detailView.classList.remove('scrolling');
                }, 1000);
            }
        });
    };

    /**
     * Setup resize handle for overlay
     */
    overlay.setupResizeHandle = function() {
        const resizeHandle = state.overlayElement?.querySelector('.resize-handle');
        if (!resizeHandle) return;

        let isResizing = false;
        let startX = 0;
        let startWidth = 0;

        resizeHandle.addEventListener('mousedown', (e) => {
            isResizing = true;
            startX = e.clientX;
            startWidth = state.overlayElement.offsetWidth;
            document.body.style.cursor = 'ew-resize';
            document.body.style.userSelect = 'none';
            e.preventDefault();
        });

        document.addEventListener('mousemove', (e) => {
            if (!isResizing) return;
            const deltaX = startX - e.clientX;
            const newWidth = startWidth + deltaX;
            if (newWidth >= 280 && newWidth <= 1650) {
                state.overlayElement.style.width = newWidth + 'px';
            }
        });

        document.addEventListener('mouseup', () => {
            if (isResizing) {
                isResizing = false;
                document.body.style.cursor = '';
                document.body.style.userSelect = '';
            }
        });
    };

    /**
     * Setup resize handle with a specific element
     * @param {HTMLElement} resizeHandle - The resize handle element
     */
    overlay.setupResizeHandleElement = function(resizeHandle) {
        if (!resizeHandle || !state.overlayElement) return;

        let isResizing = false;
        let startX = 0;
        let startWidth = 0;

        resizeHandle.addEventListener('mousedown', (e) => {
            isResizing = true;
            startX = e.clientX;
            startWidth = state.overlayElement.offsetWidth;
            document.body.style.cursor = 'ew-resize';
            document.body.style.userSelect = 'none';
            e.preventDefault();
        });

        document.addEventListener('mousemove', (e) => {
            if (!isResizing) return;
            const deltaX = startX - e.clientX;
            const newWidth = startWidth + deltaX;
            if (newWidth >= 280 && newWidth <= 1650) {
                state.overlayElement.style.width = newWidth + 'px';
            }
        });

        document.addEventListener('mouseup', () => {
            if (isResizing) {
                isResizing = false;
                document.body.style.cursor = '';
                document.body.style.userSelect = '';
            }
        });
    };

    /**
     * Create the overlay DOM element
     */
    overlay.create = function() {
        if (state.overlayElement) {
            console.log('♻️ Overlay already exists');
            return;
        }

        console.log('🎨 Creating memory overlay...');

        state.overlayElement = document.createElement('div');
        state.overlayElement.className = 'gmail-memory-overlay';
        state.overlayElement.innerHTML = `
            <div class="memory-header">
                <div class="memory-header-title">
                    <img src="${chrome.runtime.getURL('assets/icons/icon-48.png')}" alt="Engramme" class="memory-header-icon">
                    <span>Engramme</span>
                </div>
                <div class="memory-header-stats">
                    <span class="feedback-stat feedback-stat-total">
                        <span class="feedback-stat-count" id="engramme-total-feedback">0</span>
                        <span class="feedback-stat-label">rated</span>
                    </span>
                    <span class="feedback-stat feedback-stat-likes">
                        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
                        </svg>
                        <span class="feedback-stat-count" id="engramme-total-likes">0</span>
                    </span>
                    <span class="feedback-stat feedback-stat-dislikes">
                        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14H5.236a2 2 0 01-1.789-2.894l3.5-7A2 2 0 018.736 3h4.018a2 2 0 01.485.06l3.76.94m-7 10v5a2 2 0 002 2h.096c.5 0 .905-.405.905-.904 0-.715.211-1.413.608-2.008L17 13V4m-7 10h2m5-10h2a2 2 0 012 2v6a2 2 0 01-2 2h-2.5" />
                        </svg>
                        <span class="feedback-stat-count" id="engramme-total-dislikes">0</span>
                    </span>
                </div>
                <div class="memory-header-buttons">
                    <button class="close-overlay-btn" aria-label="Close">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                            <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/>
                        </svg>
                    </button>
                </div>
            </div>
            <div class="resize-handle"></div>
            <div class="memory-list">
                <div class="no-memories">Click on an email to see memories.</div>
            </div>
            <button class="chat-mode-toggle" aria-label="Toggle Chat Mode">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
            </button>
        `;

        document.body.appendChild(state.overlayElement);

        // Add resize handle element
        const resizeHandle = document.createElement('div');
        resizeHandle.className = 'memory-resize-handle';
        resizeHandle.innerHTML = '<div class="resize-handle-bar"></div>';
        state.overlayElement.appendChild(resizeHandle);
        overlay.setupResizeHandleElement(resizeHandle);

        // Setup scroll indicator for memory list
        overlay.setupScrollIndicator();

        // Create reopen tab
        const reopenTab = document.createElement('div');
        reopenTab.className = 'memory-reopen-tab';
        reopenTab.style.fontFamily = "'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";
        reopenTab.innerHTML = `
            <img src="${chrome.runtime.getURL('assets/icons/icon-48.png')}" alt="Engramme" class="reopen-tab-logo">
            <span style="font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;">Memories</span>
        `;
        reopenTab.title = 'Show memories';
        document.body.appendChild(reopenTab);

        reopenTab.addEventListener('click', () => {
            console.log('📖 Reopening overlay');
            overlay.reopen();
        });

        state.minimizeButton = document.createElement('button');
        state.minimizeButton.className = 'memory-minimize';
        state.minimizeButton.style.fontFamily = "'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";
        state.minimizeButton.innerHTML = '↑';
        state.minimizeButton.title = 'Show memories';
        document.body.appendChild(state.minimizeButton);

        // Style the collapse button
        const collapseBtn = state.overlayElement.querySelector('.memory-collapse');
        if (collapseBtn) {
            Object.assign(collapseBtn.style, {
                background: 'none',
                border: 'none',
                color: 'white',
                fontSize: '16px',
                cursor: 'pointer',
                padding: '4px',
                width: '26px',
                height: '26px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                borderRadius: '6px',
                transition: 'all 0.2s',
                opacity: '0.8'
            });
        }

        // Close button
        state.overlayElement.querySelector('.close-overlay-btn').addEventListener('click', () => {
            console.log('❌ Closing overlay');
            overlay.close();
        });

        // Setup resize handle
        overlay.setupResizeHandle();

        // Chat mode toggle button
        const chatModeToggle = state.overlayElement.querySelector('.chat-mode-toggle');
        if (chatModeToggle) {
            chatModeToggle.addEventListener('click', () => {
                console.log('💬 Toggling chat mode');
                chat.toggle();
            });
        }

        state.minimizeButton.addEventListener('click', () => {
            console.log('📖 Showing overlay from minimize button');
            overlay.show();
            state.isOverlayMinimized = false;
            state.minimizeButton.classList.remove('show');
        });

        // Initialize feedback stats from local tracker
        const tracker = window.Engramme.feedbackTracker;
        if (tracker) {
            tracker.load().then(() => overlay.updateFeedbackStats());
        }

        // // Create debug button in bottom left corner
        // if (window.Engramme.debug) {
        //     window.Engramme.debug.createButton();
        // }

        console.log('✅ Overlay created successfully');
    };

    /**
     * Show the overlay
     */
    overlay.show = function() {
        if (state.overlayElement) {
            console.log('👀 Showing overlay for', state.currentMode || 'empty');
            state.overlayElement.classList.add('show');
            overlay.adjustPosition();

            const effectiveMode = overlay.getEffectiveMode();
            if (effectiveMode === 'compose' && overlay.callbacks.updateMemorySuggestions) {
                overlay.callbacks.updateMemorySuggestions();
            } else if (effectiveMode === 'view' && overlay.callbacks.updateMemorySuggestionsForView) {
                overlay.callbacks.updateMemorySuggestionsForView();
            }
        }
    };

    /**
     * Hide the overlay
     */
    overlay.hide = function() {
        if (state.overlayElement) {
            console.log('🙈 Hiding overlay');
            state.overlayElement.classList.remove('show');
            gmail.adjustLayout(false);
        }
    };

    /**
     * Close the overlay and show reopen tab
     */
    overlay.close = function() {
        if (state.overlayElement) {
            console.log('❌ Closing overlay');
            state.overlayElement.classList.remove('show');
            state.overlayElement.classList.add('closed');
            gmail.adjustLayout(false);

            const reopenTab = document.querySelector('.memory-reopen-tab');
            if (reopenTab) {
                reopenTab.classList.add('show');
            }
        }
    };

    /**
     * Reopen the overlay
     */
    overlay.reopen = function() {
        if (state.overlayElement) {
            console.log('📖 Reopening overlay');
            state.overlayElement.classList.remove('closed');
            state.overlayElement.classList.add('show');
            gmail.adjustLayout(true);

            const reopenTab = document.querySelector('.memory-reopen-tab');
            if (reopenTab) {
                reopenTab.classList.remove('show');
            }
        }
    };

    /**
     * Hide only feedback buttons (not close button)
     * Note: Global feedback buttons removed, kept for API compatibility
     */
    overlay.hideFeedbackButtons = function() {
        // No-op: global feedback buttons removed
    };

    /**
     * Show feedback buttons
     * Note: Global feedback buttons removed, kept for API compatibility
     */
    overlay.showFeedbackButtons = function() {
        // No-op: global feedback buttons removed
    };

    /**
     * Clear query text
     */
    overlay.clearQueryText = function() {
        state.lastQueryText = '';
    };

    /**
     * Toggle feedback panel visibility
     * Note: Global feedback panel removed, kept for API compatibility
     */
    overlay.toggleFeedbackPanel = function() {
        // No-op: global feedback panel removed
    };

    /**
     * Toggle memory comment panel visibility
     * @param {string} memoryId - Memory ID
     * @param {number} index - Memory index
     */
    overlay.toggleMemoryCommentPanel = function(memoryId, index) {
        const memoryCard = state.overlayElement?.querySelector(`.memory-card[data-index="${index}"]`);
        if (memoryCard) {
            const commentPanel = memoryCard.querySelector('.memory-comment-panel');
            if (commentPanel) {
                commentPanel.classList.toggle('show');
                state.memoryCommentPanelsOpen[memoryId] = commentPanel.classList.contains('show');
            }
        }
    };

    /**
     * Clear all feedback state (delegates to feedback module)
     */
    overlay.clearAllFeedback = function() {
        feedback.clearAll();
    };

    /**
     * Update the feedback stats display in the header.
     * Reads running totals from the local FeedbackTracker.
     */
    overlay.updateFeedbackStats = function() {
        const tracker = window.Engramme.feedbackTracker;
        if (!tracker || !state.overlayElement) return;

        const totalEl = state.overlayElement.querySelector('#engramme-total-feedback');
        const likesEl = state.overlayElement.querySelector('#engramme-total-likes');
        const dislikesEl = state.overlayElement.querySelector('#engramme-total-dislikes');

        if (totalEl) totalEl.textContent = tracker.totalFeedbackCount;
        if (likesEl) likesEl.textContent = tracker.totalLikes;
        if (dislikesEl) dislikesEl.textContent = tracker.totalDislikes;
    };

    /**
     * Show empty state in the overlay
     * @param {boolean} isGmailPage - Whether current page is Gmail
     */
    overlay.showEmptyState = function(isGmailPage) {
        if (state.overlayElement) {
            const memoryList = state.overlayElement.querySelector('.memory-list');
            if (memoryList) {
                const emptyMessage = isGmailPage
                    ? 'Click on an email to see memories.'
                    : 'Memories will show up as you browse the web.';
                memoryList.innerHTML = `<div class="no-memories">${emptyMessage}</div>`;
            }

            overlay.hideFeedbackButtons();
            overlay.clearAllFeedback();
            overlay.clearQueryText();
            state.activeContext = null;
        }
    };

    /**
     * Show "not logged in" state with Google sign-in button.
     */
    overlay.showNotLoggedIn = function() {
        if (!state.overlayElement) return;
        const memoryList = state.overlayElement.querySelector('.memory-list');
        if (!memoryList) return;

        memoryList.innerHTML = `
            <div class="no-memories not-logged-in">
                <div class="not-logged-in-title">Sign in to see memories</div>
                <button class="google-btn" type="button">
                    <svg class="google-icon" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                    </svg>
                    Sign in with Google
                </button>
            </div>
        `;

        const loginBtn = memoryList.querySelector('.google-btn');
        if (loginBtn) {
            loginBtn.addEventListener('click', () => {
                loginBtn.disabled = true;
                loginBtn.textContent = 'Signing in...';
                chrome.runtime.sendMessage({ action: 'startGoogleAuth' }, (response) => {
                    if (chrome.runtime.lastError || !response || !response.success) {
                        loginBtn.disabled = false;
                        loginBtn.innerHTML = `
                            <svg class="google-icon" viewBox="0 0 24 24">
                                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                            </svg>
                            Sign in with Google
                        `;
                    } else {
                        overlay.showToast('Signed in successfully', 'success');
                    }
                });
            });
        }

        overlay.hideFeedbackButtons();
        overlay.clearQueryText();
    };

    /**
     * Show a toast feedback message
     * @param {string} message - Message to display
     * @param {string} type - 'success', 'error', 'warning', or 'loading'
     * @returns {HTMLElement} The feedback element
     */
    overlay.showToast = function(message, type = 'success') {
        const toastElement = document.createElement('div');

        if (type === 'loading') {
            toastElement.innerHTML = `
                <div style="display: flex; align-items: center; gap: 8px;">
                    <div style="
                        width: 14px;
                        height: 14px;
                        border: 2px solid rgba(255,255,255,0.3);
                        border-top-color: white;
                        border-radius: 50%;
                        animation: spin 0.6s linear infinite;
                    "></div>
                    <span>${message}</span>
                </div>
            `;
        } else {
            toastElement.innerHTML = message;
        }

        let backgroundColor = '#4CAF50'; // success (green)
        if (type === 'error') backgroundColor = '#f44336';
        if (type === 'warning') backgroundColor = '#ff9800';
        if (type === 'loading') backgroundColor = '#2196F3';

        toastElement.style.cssText = `
            position: fixed;
            top: 20px;
            right: 420px;
            background: ${backgroundColor};
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 500;
            z-index: 1000000;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            opacity: 0;
            transition: opacity 0.3s, transform 0.3s;
            transform: translateY(-10px);
        `;

        if (!document.getElementById('feedback-spinner-style')) {
            const style = document.createElement('style');
            style.id = 'feedback-spinner-style';
            style.textContent = `
                @keyframes spin {
                    to { transform: rotate(360deg); }
                }
            `;
            document.head.appendChild(style);
        }

        document.body.appendChild(toastElement);

        setTimeout(() => {
            toastElement.style.opacity = '1';
            toastElement.style.transform = 'translateY(0)';
        }, 10);

        const duration = type === 'loading' ? null : (type === 'success' ? 1500 : 2000);
        if (duration !== null) {
            toastElement._timeout = setTimeout(() => {
                overlay.dismissToast(toastElement);
            }, duration);
        }

        return toastElement;
    };

    /**
     * Dismiss a toast element
     * @param {HTMLElement} toastElement - The toast to dismiss
     */
    overlay.dismissToast = function(toastElement) {
        if (!toastElement || !toastElement.parentNode) return;

        if (toastElement._timeout) {
            clearTimeout(toastElement._timeout);
        }

        toastElement.style.opacity = '0';
        toastElement.style.transform = 'translateY(-10px)';
        setTimeout(() => {
            if (toastElement.parentNode) {
                toastElement.parentNode.removeChild(toastElement);
            }
        }, 300);
    };

    /**
     * Show insert success feedback
     */
    overlay.showInsertFeedback = function() {
        overlay.showToast('✓ Memory inserted', 'success');
    };

    // Export overlay to namespace
    window.Engramme.overlay = overlay;

    console.log('✅ Engramme Overlay module loaded');
})();

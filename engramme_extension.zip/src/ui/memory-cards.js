// memory-cards.js - Memory card rendering and detail view
// Renders memory cards, handles card interactions, and displays detail views
// Depends on: core/state.js, extraction/gmail.js, ui/feedback.js

(function() {
    'use strict';

    const memoryDisplay = {};
    const state = window.Engramme.state;
    const feedback = window.Engramme.feedback;
    const gmail = window.Engramme.gmail;

    // Callbacks for functions defined in content.js
    memoryDisplay.callbacks = {
        showFeedbackButtons: null,
        getEffectiveMode: null,
        insertMemory: null,
        toggleMemoryCommentPanel: null,
        showFeedback: null,
        setupDetailViewScrollIndicator: null
    };

    /**
     * Register callbacks from content.js
     * @param {Object} callbacks - Object with callback functions
     */
    memoryDisplay.registerCallbacks = function(callbacks) {
        Object.assign(memoryDisplay.callbacks, callbacks);
    };

    // Track scroll position when navigating to detail view
    let savedScrollPosition = null;
    let currentMemoryListSignature = null;

    // Integration logos mapping (same as web app)
    memoryDisplay.integrationLogos = {
        gmail: 'https://www.gstatic.com/images/branding/product/1x/gmail_2020q4_48dp.png',
        email: 'https://www.gstatic.com/images/branding/product/1x/gmail_2020q4_48dp.png',
        contacts: 'https://www.gstatic.com/images/branding/product/1x/contacts_2022_48dp.png',
        calendar: 'https://www.gstatic.com/images/branding/product/1x/calendar_2020q4_48dp.png',
        tasks: 'https://play-lh.googleusercontent.com/pjUulZ-Vdo7qPKxk3IRhnk8SORPlgSydSyYEjm7fGcoXO8wDyYisWXwQqEjMryZ_sqK2=w240-h480-rw',
        drive: 'https://www.gstatic.com/images/branding/product/1x/drive_2020q4_48dp.png',
        youtube: 'https://www.gstatic.com/images/branding/product/1x/youtube_48dp.png',
        photos: 'https://www.gstatic.com/images/branding/product/1x/photos_48dp.png',
        books: 'https://www.gstatic.com/images/branding/product/1x/play_books_48dp.png',
        fit: 'https://www.gstatic.com/images/branding/product/1x/gfit_48dp.png',
        slack: 'https://a.slack-edge.com/80588/marketing/img/icons/icon_slack_hash_colored.png',
        github: 'https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png',
        microsoft: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/Microsoft_logo.svg/48px-Microsoft_logo.svg.png',
        zoom: 'https://upload.wikimedia.org/wikipedia/commons/7/7b/Zoom_Communications_Logo.svg',
        asana: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/Asana_logo.svg/48px-Asana_logo.svg.png',
        browser: 'https://unpkg.com/lucide-static@latest/icons/app-window.svg',
        text: 'https://unpkg.com/lucide-static@latest/icons/file-text.svg',
        pdf: 'https://unpkg.com/lucide-static@latest/icons/file-text.svg',
        stream: 'https://unpkg.com/lucide-static@latest/icons/alert-octagon.svg',
        vscode: 'https://unpkg.com/lucide-static@latest/icons/code-2.svg'
    };

    // Color palette for avatars (matching webapp)
    const avatarColors = [
        'rgb(59, 130, 246)',   // blue-500
        'rgb(168, 85, 247)',   // purple-500
        'rgb(34, 197, 94)',    // green-500
        'rgb(249, 115, 22)',   // orange-500
        'rgb(236, 72, 153)',   // pink-500
        'rgb(99, 102, 241)'    // indigo-500
    ];

    function getThreadIdFromMemoryId(memoryId) {
        if (!memoryId || typeof memoryId !== 'string') return null;
        const underscoreIndex = memoryId.indexOf('_');
        if (underscoreIndex <= 0) return null;
        return memoryId.slice(0, underscoreIndex);
    }

    function getCurrentGmailUserIndex() {
        const pathSegments = window.location.pathname.split('/').filter(Boolean);
        const userSegmentIndex = pathSegments.indexOf('u');
        if (userSegmentIndex >= 0 && pathSegments[userSegmentIndex + 1]) {
            return pathSegments[userSegmentIndex + 1];
        }
        return '0';
    }

    function isGmailSource(source) {
        if (!source) return false;
        const normalized = source.toLowerCase();
        return normalized === 'gmail' || normalized === 'email';
    }

    function getGmailThreadUrlFromMemoryId(memoryId) {
        const threadId = getThreadIdFromMemoryId(memoryId);
        if (!threadId) return null;
        const userIndex = encodeURIComponent(getCurrentGmailUserIndex());
        return `https://mail.google.com/mail/u/${userIndex}/#all/${threadId}`;
    }

    function syncErrorCodeUI(container, memoryId) {
        const selectedCodes = state.selectedErrorCodes[memoryId] || [];
        const grid = container.querySelector(`.error-code-grid[data-memory-id="${memoryId}"]`) || container.querySelector('.error-code-grid');
        if (grid) {
            grid.querySelectorAll('.error-code-btn').forEach(btn => {
                btn.classList.toggle('active', selectedCodes.includes(btn.dataset.code));
            });
        }
        const selectedContainer = container.querySelector(`.error-code-selected[data-memory-id="${memoryId}"]`) || container.querySelector('.error-code-selected');
        if (selectedContainer) {
            selectedContainer.innerHTML = selectedCodes.map(code => `<span class="error-code-selected-pill">${code} /</span>`).join('');
            selectedContainer.classList.toggle('visible', selectedCodes.length > 0);
            selectedContainer.scrollLeft = selectedContainer.scrollWidth;
        }
    }

    function enableHorizontalWheelScroll(element) {
        if (!element) return;
        element.addEventListener('wheel', (e) => {
            if (element.scrollWidth <= element.clientWidth) return;
            if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
            element.scrollLeft += e.deltaY;
            e.preventDefault();
        }, { passive: false });
    }

    /**
     * Build a signature hash for a memory list
     * @param {Array} memories - Array of memory objects
     * @returns {string|null} Signature string or null
     */
    memoryDisplay.buildListSignature = function(memories) {
        if (!memories || memories.length === 0) return null;

        const ids = memories.map((memory, index) => memory.event_id || `temp_${index}`);
        const joined = ids.join('|');

        let hash = 2166136261;
        for (let i = 0; i < joined.length; i++) {
            hash ^= joined.charCodeAt(i);
            hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
        }

        return `${ids.length}:${(hash >>> 0).toString(16)}`;
    };

    /**
     * Display memory cards in the overlay
     * @param {Array} relevantMemories - Array of memory objects
     * @param {string} mode - 'compose' or 'view'
     * @param {string} queryText - Query text for feedback
     * @param {Object} options - Optional settings
     * @param {boolean} options.forceDisplay - If true, bypass the typed feedback check (for explicit navigation like back button)
     * @param {boolean} options.skipSelfRefFilter - If true in view mode, skip redundant self-reference filtering
     */
    memoryDisplay.display = function(relevantMemories, mode = 'compose', queryText = null, options = {}) {
        if (!state.overlayElement) {
            console.log('⚠️ No overlay element for displaying memories');
            return;
        }

        // Skip refresh if there's typed feedback, unless forceDisplay is set (e.g., back button navigation)
        if (!options.forceDisplay && feedback.hasTypedFeedback()) {
            console.log('⏸️ Skipping refresh - typed feedback present');
            return;
        }

        const memoryList = state.overlayElement.querySelector('.memory-list');
        if (!memoryList) {
            console.log('⚠️ No memory list element found');
            return;
        }

        let memoriesToDisplay = relevantMemories;
        if (mode === 'view' && !options.skipSelfRefFilter && gmail?.getCurrentThreadId) {
            const currentThreadId = gmail.getCurrentThreadId();
            if (currentThreadId) {
                memoriesToDisplay = relevantMemories.filter((memory, index) => {
                    const memoryId = memory.event_id || `temp_${index}`;
                    return getThreadIdFromMemoryId(memoryId) !== currentThreadId;
                });
            }
        }

        console.log(`🎭 Displaying ${memoriesToDisplay.length} memories for ${mode} mode`);

        state.currentMemories = memoriesToDisplay;
        currentMemoryListSignature = memoryDisplay.buildListSignature(memoriesToDisplay);
        state.memoriesTimestamp = new Date().toISOString();
        if (queryText !== null) {
            state.lastQueryText = queryText.trim();
        }

        if (memoriesToDisplay.length === 0) {
            if (mode === 'compose') {
                memoryList.innerHTML = '<div class="no-memories">No relevant memories found.</div>';
            } else {
                memoryList.innerHTML = '<div class="no-memories">No relevant memories found for this email thread.</div>';
            }
            if (memoryDisplay.callbacks.showFeedbackButtons) {
                memoryDisplay.callbacks.showFeedbackButtons();
            }
            return;
        }

        if (memoryDisplay.callbacks.showFeedbackButtons) {
            memoryDisplay.callbacks.showFeedbackButtons();
        }

        const memoriesHTML = memoriesToDisplay.map((memory, index) => {
            const headline = memory.headline || '';
            const narrative = memory.narrative || '';
            const memoryId = memory.event_id || `temp_${index}`;
            const rating = state.memoryRatings[memoryId] || 0;

            const participants = memory.participants || [];
            const participantCount = participants.length || 0;
            const displayCount = Math.min(participantCount, 3);
            const overflowCount = participantCount > 3 ? participantCount - 3 : 0;

            let avatarsHTML = '';
            if (participantCount > 0) {
                for (let i = 0; i < displayCount; i++) {
                    const participant = participants[i];
                    const participantName = typeof participant === 'string' ? participant : (participant.name || 'Unknown');
                    const initials = participantName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
                    const showInitials = initials && initials !== 'UN';
                    const color = avatarColors[i % avatarColors.length];
                    avatarsHTML += `<div class="avatar-item" style="background-color: ${color}; color: white;" data-tooltip="${participantName}" aria-label="${participantName}">${showInitials ? initials : '👤'}</div>`;
                }
                if (overflowCount > 0) {
                    avatarsHTML += `<div class="avatar-overflow">+${overflowCount}</div>`;
                }
            }

            const source = memory.source || 'unknown';
            const sourceLogo = memoryDisplay.integrationLogos[source.toLowerCase()];
            const sourceIconHTML = sourceLogo
                ? `<span class="source-icon" data-tooltip="${source}" aria-label="${source}"><img src="${sourceLogo}" alt="${source}" style="width: 24px; height: 24px; object-fit: contain;" /></span>`
                : '';

            return `
                <div class="memory-card ${mode === 'view' ? 'view-mode' : ''}" data-index="${index}" data-memory-id="${memoryId}">
                    <div class="memory-card-header">
                        <div class="memory-card-left">
                            <div class="memory-icon">${sourceIconHTML}</div>
                            ${memory.when ? `<span class="memory-date">${memory.when}</span>` : ''}
                        </div>
                        <div class="memory-avatars">
                            ${avatarsHTML}
                        </div>
                    </div>
                    <div class="memory-content ${mode === 'compose' ? 'clickable' : ''}">
                        ${headline ? `<div class="memory-headline">${headline}</div>` : ''}
                        ${narrative ? `<div class="memory-narrative">${narrative}</div>` : ''}
                    </div>
                    <div class="memory-card-actions">
                        <button class="memory-action-btn rating-btn thumbs-up ${rating === 1 ? 'active' : ''}" data-memory-id="${memoryId}" data-index="${index}" data-rating="1" aria-label="Relevant">
                            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.60L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
                            </svg>
                        </button>
                        <button class="memory-action-btn rating-btn thumbs-down ${rating === -1 ? 'active' : ''}" data-memory-id="${memoryId}" data-index="${index}" data-rating="-1" aria-label="Not relevant">
                            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14H5.236a2 2 0 01-1.789-2.894l3.5-7A2 2 0 018.736 3h4.018a2 2 0 01.485.06l3.76.94m-7 10v5a2 2 0 002 2h.096c.5 0 .905-.405.905-.904 0-.715.211-1.413.608-2.008L17 13V4m-7 10h2m5-10h2a2 2 0 012 2v6a2 2 0 01-2 2h-2.5" />
                            </svg>
                        </button>
                        <button class="memory-action-btn comment-toggle-btn" data-memory-id="${memoryId}" data-index="${index}" aria-label="Add comment">
                            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                            </svg>
                        </button>
                        <button class="memory-action-btn copy-memory-btn" data-index="${index}" aria-label="Copy memory text">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M6 6V4.13168C6 3.38309 6 3.00854 6.14532 2.72786C6.27315 2.47761 6.47761 2.27315 6.72786 2.14532C7.00854 2 7.38285 2 8.13144 2H11.8687C12.6173 2 12.9913 2 13.2719 2.14532C13.5222 2.27315 13.7269 2.47761 13.8548 2.72786C14.0001 3.00854 14.0001 3.38283 14.0001 4.13142V7.86868C14.0001 8.61727 14.0001 8.99148 13.8548 9.27216C13.7269 9.52241 13.5218 9.72705 13.2715 9.85488C12.9911 10 12.6177 10 11.8706 10H10M6 6H4.13168C3.38309 6 3.00854 6 2.72786 6.14532C2.47761 6.27315 2.27315 6.47761 2.14532 6.72786C2 7.00854 2 7.38285 2 8.13144V11.8687C2 12.6173 2 12.9913 2.14532 13.2719C2.27315 13.5222 2.47761 13.7269 2.72786 13.8548C3.00827 14 3.38237 14 4.13056 14H7.86944C8.61763 14 8.99145 14 9.27184 13.8548C9.52209 13.7269 9.72705 13.5218 9.85488 13.2715C10 12.9911 10 12.6177 10 11.8706V10M6 6H7.86832C8.61691 6 8.99146 6 9.27214 6.14532C9.52239 6.27315 9.72705 6.47761 9.85488 6.72786C10 7.00825 10 7.38242 10 8.13061L10 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                    </div>
                    <div class="memory-comment-panel" data-memory-id="${memoryId}" data-index="${index}">
                        <div class="error-code-grid" data-memory-id="${memoryId}">
                            ${window.Engramme.errorCodes.map(ec => `
                                <button class="error-code-btn${(state.selectedErrorCodes[memoryId] || []).includes(ec.code) ? ' active' : ''}" data-code="${ec.code}" data-memory-id="${memoryId}">${ec.label}</button>
                            `).join('')}
                        </div>
                        <div class="error-code-selected ${((state.selectedErrorCodes[memoryId] || []).length) ? 'visible' : ''}" data-memory-id="${memoryId}">
                            ${(state.selectedErrorCodes[memoryId] || []).map(code => `<span class="error-code-selected-pill">${code} /</span>`).join('')}
                        </div>
                        <div class="memory-comment-input-wrapper">
                            <textarea class="memory-comment-input" data-memory-id="${memoryId}" data-index="${index}" placeholder="Add your comment..." rows="2" style="color: #000 !important;"></textarea>
                            <button class="memory-comment-submit-btn" data-memory-id="${memoryId}" data-index="${index}" aria-label="Submit feedback">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                                    <path d="M15.854 7.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708-.708L14.293 8.5H.5a.5.5 0 0 1 0-1h13.793L8.146.354a.5.5 0 1 1 .708-.708l7 7z"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        memoryList.innerHTML = memoriesHTML;

        // Sync global rating buttons
        const globalRatingButtons = state.overlayElement.querySelectorAll('.memory-header .global-rating-btn');
        globalRatingButtons.forEach(btn => {
            const btnRating = parseInt(btn.dataset.rating);
            if (btnRating === 1) {
                btn.classList.toggle('active', state.globalRating === 1);
            } else if (btnRating === -1) {
                btn.classList.toggle('active', state.globalRating === -1);
            }
        });

        // Rating buttons
        memoryList.querySelectorAll('.rating-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const memoryId = btn.dataset.memoryId;
                const index = parseInt(btn.dataset.index);
                const rating = parseInt(btn.dataset.rating);
                feedback.handleMemoryRating(memoryId, index, rating);
                if (!state.memoryCommentPanelsOpen[memoryId] && memoryDisplay.callbacks.toggleMemoryCommentPanel) {
                    memoryDisplay.callbacks.toggleMemoryCommentPanel(memoryId, index);
                }
            });
        });

        // Comment toggle buttons
        memoryList.querySelectorAll('.comment-toggle-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const memoryId = btn.dataset.memoryId;
                const index = parseInt(btn.dataset.index);
                if (memoryDisplay.callbacks.toggleMemoryCommentPanel) {
                    memoryDisplay.callbacks.toggleMemoryCommentPanel(memoryId, index);
                }
            });
        });

        // Comment inputs
        memoryList.querySelectorAll('.memory-comment-input').forEach(input => {
            const memoryId = input.dataset.memoryId;

            if (state.memoryComments[memoryId]) {
                input.value = state.memoryComments[memoryId];
            }

            input.addEventListener('input', (e) => {
                state.memoryComments[memoryId] = e.target.value.trim();
                feedback.updateSubmitButtonState();
                // Remove submitted tint if text is cleared
                if (!e.target.value.trim()) {
                    input.classList.remove('submitted');
                }
            });

            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    feedback.submit();
                }
            });
        });

        // Restore comment panel state (also show if comment or error codes exist)
        memoryList.querySelectorAll('.memory-comment-panel').forEach(panel => {
            const memoryId = panel.dataset.memoryId;
            const hasComment = Boolean(state.memoryComments[memoryId]);
            const hasErrorCodes = Array.isArray(state.selectedErrorCodes[memoryId]) && state.selectedErrorCodes[memoryId].length > 0;
            if (state.memoryCommentPanelsOpen[memoryId] || hasComment || hasErrorCodes) {
                panel.classList.add('show');
            }
        });

        // Comment submit buttons
        memoryList.querySelectorAll('.memory-comment-submit-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                feedback.submit();
            });
        });

        // Error code buttons
        memoryList.querySelectorAll('.error-code-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const memoryId = btn.dataset.memoryId;
                const code = btn.dataset.code;

                const selectedCodes = state.selectedErrorCodes[memoryId] || [];
                const codeIndex = selectedCodes.indexOf(code);
                if (codeIndex >= 0) {
                    selectedCodes.splice(codeIndex, 1);
                } else {
                    selectedCodes.push(code);
                }
                if (selectedCodes.length) {
                    state.selectedErrorCodes[memoryId] = selectedCodes;
                } else {
                    delete state.selectedErrorCodes[memoryId];
                }

                const card = btn.closest('.memory-card') || memoryList;
                syncErrorCodeUI(card, memoryId);
            });
        });

        // Enable wheel-to-horizontal scrolling for error code grids and selected codes
        memoryList.querySelectorAll('.error-code-grid').forEach(enableHorizontalWheelScroll);
        memoryList.querySelectorAll('.error-code-selected').forEach(container => {
            enableHorizontalWheelScroll(container);
            container.scrollLeft = container.scrollWidth;
        });

        // Restore error code grid scroll positions for all memory cards
        memoryList.querySelectorAll('.error-code-grid').forEach(grid => {
            const gridMemoryId = grid.dataset.memoryId;
            if (gridMemoryId && state.errorCodeScrollPositions[gridMemoryId] !== undefined) {
                setTimeout(() => {
                    grid.scrollLeft = state.errorCodeScrollPositions[gridMemoryId];
                }, 0);
            }
        });

        // Copy buttons
        memoryList.querySelectorAll('.copy-memory-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.stopPropagation();
                const index = parseInt(btn.dataset.index);
                const narrative = memoriesToDisplay[index].narrative || '';

                try {
                    await navigator.clipboard.writeText(narrative);
                    const originalHTML = btn.innerHTML;
                    btn.innerHTML = `
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5">
                            <path d="M13.854 3.646L6 11.5l-3.5-3.5"/>
                        </svg>
                    `;
                    btn.style.color = '#10b981';

                    setTimeout(() => {
                        btn.innerHTML = originalHTML;
                        btn.style.color = '';
                    }, 2000);

                    console.log('✅ Memory text copied to clipboard');
                } catch (err) {
                    console.error('❌ Failed to copy:', err);
                    if (memoryDisplay.callbacks.showFeedback) {
                        memoryDisplay.callbacks.showFeedback('Failed to copy', 'error');
                    }
                }
            });
        });

        // Card click handlers
        memoryList.querySelectorAll('.memory-card').forEach((card, index) => {
            card.addEventListener('click', (e) => {
                if (e.target.closest('.memory-action-btn') || e.target.closest('.memory-comment-panel')) {
                    return;
                }

                const memoryId = card.dataset.memoryId;

                // Save error code grid scroll position before navigating to detail view
                const errorGrid = card.querySelector('.error-code-grid');
                if (errorGrid) {
                    state.errorCodeScrollPositions[memoryId] = errorGrid.scrollLeft;
                }
                const containerRect = memoryList.getBoundingClientRect();
                const cardRect = card.getBoundingClientRect();
                const listSignature = currentMemoryListSignature;

                if (!containerRect.height || containerRect.height <= 0) {
                    savedScrollPosition = null;
                } else if (!listSignature) {
                    savedScrollPosition = null;
                } else {
                    const fractionalY = (cardRect.top - containerRect.top) / containerRect.height;
                    savedScrollPosition = { memoryId, fractionalY, listSignature };
                }

                memoryDisplay.showDetail(memoriesToDisplay[index], index, mode);
            });
            card.style.cursor = 'pointer';
        });

        // Source icon click handlers (Gmail only)
        memoryList.querySelectorAll('.source-icon').forEach((icon) => {
            icon.addEventListener('click', (e) => {
                const card = icon.closest('.memory-card');
                if (!card) return;
                const index = parseInt(card.dataset.index, 10);
                if (!Number.isInteger(index) || index < 0) return;
                const memory = memoriesToDisplay[index];
                if (!memory) return;
                if (!isGmailSource(memory?.source)) return;
                const memoryId = card.dataset.memoryId || memory.event_id || `temp_${index}`;
                const threadUrl = getGmailThreadUrlFromMemoryId(memoryId);
                if (threadUrl) {
                    e.stopPropagation();
                    window.location.assign(threadUrl);
                }
            });
        });

        feedback.updateSubmitButtonState();
        feedback.updateThumbVisualStates();
    };

    /**
     * Show detailed view of a memory
     * @param {Object} memory - Memory object
     * @param {number} index - Memory index
     * @param {string} mode - 'compose' or 'view'
     */
    memoryDisplay.showDetail = function(memory, index, mode) {
        const memoryList = state.overlayElement?.querySelector('.memory-list');
        if (!memoryList) return;

        const headline = memory.headline || '';
        const narrative = memory.narrative || '';
        const memoryId = memory.event_id || `temp_${index}`;
        const rating = state.memoryRatings[memoryId] || 0;
        const participants = memory.participants || [];

        let participantsHTML = '';
        if (participants.length > 0) {
            participantsHTML = participants.map((p, i) => {
                const participantName = typeof p === 'string' ? p : (p.name || 'Unknown');
                const initials = participantName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
                const showInitials = initials && initials !== 'UN';
                const color = avatarColors[i % avatarColors.length];
                return `
                    <div class="participant-item">
                        <div class="participant-avatar" style="background-color: ${color}; color: white;">${showInitials ? initials : '👤'}</div>
                        <span class="participant-name">${participantName}</span>
                    </div>
                `;
            }).join('');
        }

        const effectiveMode = memoryDisplay.callbacks.getEffectiveMode ? memoryDisplay.callbacks.getEffectiveMode() : mode;
        let emailSubject = gmail.getEmailSubject(effectiveMode) || 'Email';
        if (emailSubject.length > 50) {
            emailSubject = emailSubject.substring(0, 50) + '...';
        }

        // Use actual headline for the title (no truncation needed)
        const memoryTitle = headline;

        const source = memory.source || 'unknown';
        const sourceLogo = memoryDisplay.integrationLogos[source.toLowerCase()];
        const sourceIconHTML = sourceLogo
            ? `<span class="source-icon" data-tooltip="${source}" aria-label="${source}"><img src="${sourceLogo}" alt="${source}" style="width: 24px; height: 24px; object-fit: contain;" /></span>`
            : '';

        const detailHTML = `
            <div class="memory-detail-view" data-memory-id="${memoryId}">
                <div class="memory-detail-header-row">
                    <button class="back-btn">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M15 18l-6-6 6-6"/>
                        </svg>
                    </button>

                    <div class="memory-source-icon">${sourceIconHTML}</div>
                    <div class="memory-source-info">
                        <div class="memory-source-label">${emailSubject}</div>
                        ${memory.when ? `<div class="memory-source-date">${memory.when}</div>` : ''}
                    </div>
                </div>

                <div class="memory-detail-content-wrapper">
                    <div class="memory-detail-title">${memoryTitle}</div>

                    <div class="memory-detail-content">
                        ${narrative}
                    </div>

                    ${participantsHTML ? `<div class="memory-detail-participants">
                        ${participantsHTML}
                    </div>` : ''}
                </div>

                <div class="memory-detail-actions">
                    <button class="memory-detail-action-btn rating-btn thumbs-up ${rating === 1 ? 'active' : ''}" data-rating="1" aria-label="Relevant">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
                        </svg>
                    </button>
                    <button class="memory-detail-action-btn rating-btn thumbs-down ${rating === -1 ? 'active' : ''}" data-rating="-1" aria-label="Not relevant">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14H5.236a2 2 0 01-1.789-2.894l3.5-7A2 2 0 018.736 3h4.018a2 2 0 01.485.06l3.76.94m-7 10v5a2 2 0 002 2h.096c.5 0 .905-.405.905-.904 0-.715.211-1.413.608-2.008L17 13V4m-7 10h2m5-10h2a2 2 0 012 2v6a2 2 0 01-2 2h-2.5" />
                        </svg>
                    </button>
                    <button class="memory-detail-action-btn comment-btn" aria-label="Add comment">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                        </svg>
                    </button>
                    <button class="memory-detail-action-btn copy-btn" aria-label="Copy memory text">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6 6V4.13168C6 3.38309 6 3.00854 6.14532 2.72786C6.27315 2.47761 6.47761 2.27315 6.72786 2.14532C7.00854 2 7.38285 2 8.13144 2H11.8687C12.6173 2 12.9913 2 13.2719 2.14532C13.5222 2.27315 13.7269 2.47761 13.8548 2.72786C14.0001 3.00854 14.0001 3.38283 14.0001 4.13142V7.86868C14.0001 8.61727 14.0001 8.99148 13.8548 9.27216C13.7269 9.52241 13.5218 9.72705 13.2715 9.85488C12.9911 10 12.6177 10 11.8706 10H10M6 6H4.13168C3.38309 6 3.00854 6 2.72786 6.14532C2.47761 6.27315 2.27315 6.47761 2.14532 6.72786C2 7.00854 2 7.38285 2 8.13144V11.8687C2 12.6173 2 12.9913 2.14532 13.2719C2.27315 13.5222 2.47761 13.7269 2.72786 13.8548C3.00827 14 3.38237 14 4.13056 14H7.86944C8.61763 14 8.99145 14 9.27184 13.8548C9.52209 13.7269 9.72705 13.5218 9.85488 13.2715C10 12.9911 10 12.6177 10 11.8706V10M6 6H7.86832C8.61691 6 8.99146 6 9.27214 6.14532C9.52239 6.27315 9.72705 6.47761 9.85488 6.72786C10 7.00825 10 7.38242 10 8.13061L10 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                </div>

                <div class="memory-comment-panel" data-index="${index}" data-memory-id="${memoryId}">
                    <div class="error-code-grid" data-memory-id="${memoryId}">
                        ${window.Engramme.errorCodes.map(ec => `
                            <button class="error-code-btn${(state.selectedErrorCodes[memoryId] || []).includes(ec.code) ? ' active' : ''}" data-code="${ec.code}" data-memory-id="${memoryId}">${ec.label}</button>
                        `).join('')}
                    </div>
                    <div class="error-code-selected ${((state.selectedErrorCodes[memoryId] || []).length) ? 'visible' : ''}" data-memory-id="${memoryId}">
                        ${(state.selectedErrorCodes[memoryId] || []).map(code => `<span class="error-code-selected-pill">${code} /</span>`).join('')}
                    </div>
                    <div class="memory-comment-input-wrapper">
                        <textarea class="memory-comment-input" data-index="${index}" data-memory-id="${memoryId}" placeholder="Add your comment..." rows="3" style="color: #000 !important;"></textarea>
                        <button class="memory-comment-submit-btn" data-index="${index}" data-memory-id="${memoryId}" aria-label="Submit feedback">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                                <path d="M15.854 7.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708-.708L14.293 8.5H.5a.5.5 0 0 1 0-1h13.793L8.146.354a.5.5 0 1 1 .708-.708l7 7z"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        `;

        memoryList.innerHTML = detailHTML;

        // Setup scroll indicator
        if (memoryDisplay.callbacks.setupDetailViewScrollIndicator) {
            setTimeout(() => {
                memoryDisplay.callbacks.setupDetailViewScrollIndicator();
            }, 100);
        }

        // Back button
        const backBtn = memoryList.querySelector('.back-btn');
        backBtn.addEventListener('click', () => {
            // Save error code grid scroll position before going back to list view
            const detailErrorGrid = memoryList.querySelector('.error-code-grid');
            if (detailErrorGrid) {
                state.errorCodeScrollPositions[memoryId] = detailErrorGrid.scrollLeft;
            }

            // Use forceDisplay to bypass typed feedback check, and skip self-ref filtering because list is already filtered
            memoryDisplay.display(state.currentMemories, mode, null, { forceDisplay: true, skipSelfRefFilter: true });

            if (savedScrollPosition) {
                setTimeout(() => {
                    const memoryListEl = state.overlayElement.querySelector('.memory-list');
                    if (!memoryListEl) return;

                    if (!currentMemoryListSignature || savedScrollPosition.listSignature !== currentMemoryListSignature) {
                        memoryListEl.scrollTop = 0;
                        savedScrollPosition = null;
                        return;
                    }

                    const targetCard = memoryListEl.querySelector(`.memory-card[data-memory-id="${savedScrollPosition.memoryId}"]`);
                    if (!targetCard) {
                        memoryListEl.scrollTop = 0;
                        savedScrollPosition = null;
                        return;
                    }

                    const containerRect = memoryListEl.getBoundingClientRect();
                    if (!containerRect.height || containerRect.height <= 0) {
                        savedScrollPosition = null;
                        return;
                    }

                    const targetY = savedScrollPosition.fractionalY * containerRect.height;
                    const cardRect = targetCard.getBoundingClientRect();
                    const cardPositionInContent = cardRect.top - containerRect.top + memoryListEl.scrollTop;
                    const newScrollTop = cardPositionInContent - targetY;

                    memoryListEl.scrollTop = Math.max(0, newScrollTop);
                    savedScrollPosition = null;
                }, 0);
            }
        });

        // Rating buttons
        memoryList.querySelectorAll('.rating-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const rating = parseInt(btn.dataset.rating);
                feedback.handleMemoryRating(memoryId, index, rating);
                const detailCommentPanel = memoryList.querySelector('.memory-comment-panel');
                if (detailCommentPanel && !detailCommentPanel.classList.contains('show')) {
                    detailCommentPanel.classList.add('show');
                }
            });
        });

        // Comment button
        const commentBtn = memoryList.querySelector('.comment-btn');
        if (commentBtn) {
            commentBtn.addEventListener('click', () => {
                const commentPanel = memoryList.querySelector('.memory-comment-panel');
                if (commentPanel) {
                    commentPanel.classList.toggle('show');
                }
            });
        }

        // Comment input
        const commentInput = memoryList.querySelector('.memory-comment-input');
        if (commentInput) {
            commentInput.addEventListener('input', (e) => {
                state.memoryComments[memoryId] = e.target.value.trim();
                feedback.updateSubmitButtonState();
                // Remove submitted tint if text is cleared
                if (!e.target.value.trim()) {
                    commentInput.classList.remove('submitted');
                }
            });

            commentInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    feedback.submit();
                }
            });

            if (state.memoryComments[memoryId]) {
                commentInput.value = state.memoryComments[memoryId];
            }
        }

        const detailCommentPanel = memoryList.querySelector('.memory-comment-panel');
        const hasComment = Boolean(state.memoryComments[memoryId]);
        const hasErrorCodes = Array.isArray(state.selectedErrorCodes[memoryId]) && state.selectedErrorCodes[memoryId].length > 0;
        if (detailCommentPanel && (hasComment || hasErrorCodes)) {
            detailCommentPanel.classList.add('show');
        }

        // Comment submit button
        const commentSubmitBtn = memoryList.querySelector('.memory-comment-submit-btn');
        if (commentSubmitBtn) {
            commentSubmitBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                feedback.submit();
            });
        }

        // Error code buttons (detail view)
        memoryList.querySelectorAll('.error-code-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const btnMemoryId = btn.dataset.memoryId;
                const code = btn.dataset.code;

                const selectedCodes = state.selectedErrorCodes[btnMemoryId] || [];
                const codeIndex = selectedCodes.indexOf(code);
                if (codeIndex >= 0) {
                    selectedCodes.splice(codeIndex, 1);
                } else {
                    selectedCodes.push(code);
                }
                if (selectedCodes.length) {
                    state.selectedErrorCodes[btnMemoryId] = selectedCodes;
                } else {
                    delete state.selectedErrorCodes[btnMemoryId];
                }

                syncErrorCodeUI(memoryList, btnMemoryId);
            });
        });

        // Enable wheel-to-horizontal scrolling for error code grid and selected codes in detail view
        memoryList.querySelectorAll('.error-code-grid').forEach(enableHorizontalWheelScroll);
        memoryList.querySelectorAll('.error-code-selected').forEach(container => {
            enableHorizontalWheelScroll(container);
            container.scrollLeft = container.scrollWidth;
        });

        // Restore error code grid scroll position in detail view
        const detailErrorGrid = memoryList.querySelector('.error-code-grid');
        if (detailErrorGrid && state.errorCodeScrollPositions[memoryId] !== undefined) {
            setTimeout(() => {
                detailErrorGrid.scrollLeft = state.errorCodeScrollPositions[memoryId];
            }, 0);
        }

        // Copy button
        const copyBtn = memoryList.querySelector('.copy-btn');
        if (copyBtn) {
            copyBtn.addEventListener('click', async () => {
                try {
                    await navigator.clipboard.writeText(narrative);
                    const originalHTML = copyBtn.innerHTML;
                    copyBtn.innerHTML = `
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5">
                            <path d="M13.854 3.646L6 11.5l-3.5-3.5"/>
                        </svg>
                    `;
                    copyBtn.style.color = '#10b981';

                    setTimeout(() => {
                        copyBtn.innerHTML = originalHTML;
                        copyBtn.style.color = '';
                    }, 2000);
                } catch (err) {
                    console.error('❌ Failed to copy:', err);
                    if (memoryDisplay.callbacks.showFeedback) {
                        memoryDisplay.callbacks.showFeedback('Failed to copy', 'error');
                    }
                }
            });
        }

        // Use memory button
        const useMemoryBtn = memoryList.querySelector('.use-memory-btn');
        if (useMemoryBtn && memoryDisplay.callbacks.insertMemory) {
            useMemoryBtn.addEventListener('click', () => {
                memoryDisplay.callbacks.insertMemory(narrative);
                setTimeout(() => {
                    memoryDisplay.display(state.currentMemories, mode);
                }, 500);
            });
        }
    };

    // Export memoryDisplay to namespace
    window.Engramme.memoryDisplay = memoryDisplay;

    console.log('✅ Engramme Memory Display module loaded');
})();

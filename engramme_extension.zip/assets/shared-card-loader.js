// shared-card-loader.js — Dynamic loader for shared memory card JS
// This page runs in a sandboxed iframe (no Chrome API access) so it
// communicates with the content script via postMessage. The content
// script fetches memory-card.js from the webapp backend and sends it
// here for execution. Card rendering logic always comes from the
// backend — single source of truth. This loader is just infrastructure.

let bridgeNonce = null;
let loaderReadySent = false;
let scriptInjected = false;

function isValidNonce(value) {
  return typeof value === 'string' && value.length >= 16;
}

function postToParent(type, payload = {}) {
  if (!bridgeNonce) return;
  window.parent.postMessage({
    type: `engramme:${type}`,
    bridgeNonce,
    payload
  }, '*');
}

window.addEventListener('message', (e) => {
  if (e.source !== window.parent) return;

  const data = e.data;
  if (!data || typeof data !== 'object') return;

  if (data.type === 'engramme:init') {
    if (!isValidNonce(data.bridgeNonce)) return;
    if (bridgeNonce && bridgeNonce !== data.bridgeNonce) return;

    bridgeNonce = data.bridgeNonce;
    window.__engrammeBridgeNonce = bridgeNonce;

    if (!loaderReadySent) {
      loaderReadySent = true;
      postToParent('loaderReady', {});
    }
    return;
  }

  if (!bridgeNonce || data.bridgeNonce !== bridgeNonce) return;
  if (data.type !== 'engramme:injectScript' || scriptInjected || !data.js) return;

  scriptInjected = true;
  const script = document.createElement('script');
  script.textContent = data.js;
  document.body.appendChild(script);
});

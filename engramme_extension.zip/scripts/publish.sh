#!/bin/bash

# Chrome Web Store Publish Script
# Usage: ./publish.sh [--auto-publish]

set -e

EXTENSION_ID="bbgghegadcfkngdbejoalcdkjhljkcia"
CLIENT_ID="537762477239-hes0lj4evcclai6bt888h8ruurps5hgo.apps.googleusercontent.com"
CLIENT_SECRET="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"
REFRESH_TOKEN="1//06TACZc9wmMA7CgYIARAAGAYSNwF-L9Ir-4xX39y8_PIYXOs1cTJsi12yr5IkQcXx-TYiYSul-d7u-eYiB737Avp0MGPJ-3YwvS0"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ZIP_FILE="$SCRIPT_DIR/extension.zip"

echo "📦 Creating extension zip..."
cd "$SCRIPT_DIR"
rm -f "$ZIP_FILE"
zip -r "$ZIP_FILE" . -x "*.git*" -x "*.md" -x "publish.sh" -x "*.zip"

echo "🔑 Getting access token..."
ACCESS_TOKEN=$(curl -s -X POST "https://oauth2.googleapis.com/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "client_id=$CLIENT_ID" \
  -d "client_secret=$CLIENT_SECRET" \
  -d "refresh_token=$REFRESH_TOKEN" \
  -d "grant_type=refresh_token" | grep -o '"access_token":"[^"]*"' | cut -d'"' -f4)

if [ -z "$ACCESS_TOKEN" ]; then
  echo "❌ Failed to get access token"
  exit 1
fi

echo "⬆️  Uploading to Chrome Web Store..."
UPLOAD_RESPONSE=$(curl -s -X PUT \
  "https://www.googleapis.com/upload/chromewebstore/v1.1/items/$EXTENSION_ID" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "x-goog-api-version: 2" \
  -T "$ZIP_FILE")

echo "$UPLOAD_RESPONSE"

if echo "$UPLOAD_RESPONSE" | grep -q '"uploadState":"SUCCESS"'; then
  echo "✅ Upload successful!"

  if [ "$1" == "--auto-publish" ]; then
    echo "🚀 Publishing..."
    PUBLISH_RESPONSE=$(curl -s -X POST \
      "https://www.googleapis.com/chromewebstore/v1.1/items/$EXTENSION_ID/publish" \
      -H "Authorization: Bearer $ACCESS_TOKEN" \
      -H "x-goog-api-version: 2" \
      -H "Content-Length: 0")
    echo "$PUBLISH_RESPONSE"

    if echo "$PUBLISH_RESPONSE" | grep -q '"status":\["OK"\]'; then
      echo "✅ Published successfully!"
    else
      echo "⚠️  Publish may require manual review"
    fi
  else
    echo "ℹ️  Run with --auto-publish to publish automatically"
  fi
else
  echo "❌ Upload failed"
  exit 1
fi

rm -f "$ZIP_FILE"
echo "🎉 Done!"

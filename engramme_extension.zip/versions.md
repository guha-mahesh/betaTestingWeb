# Engramme Assistant - Version History

## Version 4.3.0
- **Inbox Guard**: Overlay no longer falsely triggers email-view mode on the inbox
  - URL-based thread detection prevents subject-element false positives
  - Inbox always shows "Click on an email to see memories."
- **Dynamic Overlay States**: Accurate, immediate state transitions when navigating emails
  - Instant "Searching memories..." feedback on email click (no stale messages)
  - Loading state always shown before API calls (removed isMeaningfulChange gate)
  - Default overlay content no longer shows compose-mode text on Gmail

## Version 4.2.0
- **Gmail Scraping Improvements**: Complete rewrite of email thread extraction
  - 2-character codes for compact metadata (fr:, to:, cc:, bc:, dt:, ct:, sb:, dr:)
  - Proper To/Cc/Bcc recipient parsing from Gmail's collapsed and expanded headers
  - Message numbering (m1:, m2:, etc.) for multi-message threads
  - Draft detection with dr: prefix
  - Format: "Name <email>" for all participants
  - Deduplication of recipients across header types
- **Recall Prioritization**: Changed truncation from first 1000 to last 1000 characters
  - Prioritizes recent messages in long email threads
  - Better context for ongoing conversations
- **Domain Blocking**: Refined to block only app.engramme.com (not all engramme.com subdomains)

## Version 4.1.0
- **Developer Mode**: Added password-protected Developer Mode for internal testing
  - Environment switching between Dev/Staging/Production
  - Hidden UI (click dot in footer, password: `mm-internal-user`)
  - Dynamic API endpoint configuration based on selected environment
  - Visual indicators showing current environment
  - Seamless Google Sign-In across all environments
- **Multi-Environment Support**:
  - Centralized environment configuration for all API endpoints
  - Support for dev, staging, and prod Firebase/backend resources
  - Dynamic backend URL selection for Google Meets transcription
  - Environment-aware diagnostic script
- **Architecture Improvements**:
  - Updated manifest with host permissions for all environments
  - Inline environment config in background.js for compatibility
  - Environment state persistence in chrome.storage

## Version 4.0.0
- **Major Scraping Overhaul**: Complete rewrite of content extraction system with site-specific scrapers
- **New Site Support**: Added specialized scrapers for:
  - Amazon (product pages, search results, homepage)
  - Google Search (search results extraction)
  - Google Meets (meeting capture with audio transcription via 11labs)
  - Gmail (improved email content extraction)
  - Reddit (post and subreddit page extraction)
  - ChatGPT (conversation snippet capture)
  - San Francisco Chronicle (homepage cards and article pages)
  - Google Docs (document content extraction)
  - LinkedIn (profile and feed extraction)
- **Scraping Architecture**: Reorganized all scraping files under `/sites` directory with proper routing
- **Smart Extraction**: Viewport-only extraction for long/scrolling pages to reduce noise
- **Performance Optimization**: Debounced generic page scraping on scroll (3-second idle delay)
- **UX Improvements**:
  - Skip overlay and extraction on engramme.com domains
  - Show "Today" and "Yesterday" for recent dates (0-1 day old)
  - Enable Amazon homepage scraping with recommendation capture
- **Multiple Scraping Refinements**:
  - Tuned Amazon scraping for product details, features, and search results
  - Improved Google Search result extraction
  - Fixed Google Meets scraping across multiple iterations
  - Enhanced Gmail extraction reliability
- **Design Integration**: Merged UI/design branch with Google sign-in improvements

## Version 3.6.3
- **Auth Flow**: Moved Google sign-in handling to background for automatic auth refresh
- **Overlay UI**: Added Google sign-in button and removed the "API Key not configured" message
- **Sign-out UX**: Refresh open tabs after sign out to reset state

## Version 3.6.2
- **Integration Icons**: Expanded icon mapping for browser/text/pdf/vscode sources
- **Source Tooltips**: Added styled tooltips for source icons and participant avatars


## Version 3.6.1
- **Error Code Feedback UX**: Added multi-select error codes, improved selected code display, and kept comment box visible with long selections
- **Feedback Flow**: Auto-open comment panels on thumb feedback; improved error code scrolling on non-trackpad mice

## Version 3.6.0
- **Google Log In**: Implemented google sign in for the chrome extension
- **Manifest addition**: added a key: field to the Manifest to ensure that the extension ID is standard across all machines.

## Version 3.5.2 (Current)

- **Design Updates**: Changed all blue outlines to black/dark gray to match company aesthetic
- **Date Formatting**: Fixed date display from "01/01/2026" format to "January 1st, 2026" format with robust handling
- **UI Readability**: Improved selected code UI for better text readability

## Version 3.5.1

- **Error Code System**: Added error code functionality with user-visible error codes
- **Error Code UI**: Display exactly which error code is being submitted
- **Error Code Organization**: Reordered error codes to put most common ones first
- **Feedback Integration**: Integrated error codes with feedback clearing, removed redundant functions

## Version 3.5.0

- standardized feedback following schema
- **Request Serialization**: Queued refresh system to prevent duplicate concurrent requests
- **Flicker Reduction**: Optimized rendering to minimize UI flicker during updates
- **Headline Display**: Prominent display of memory headlines in list and detail views
- **Styled Narratives**: Design-spec compliant headline and narrative styling
- **Modular Codebase**
- **Empty Query Protection**: Prevents feedback submission on empty queries
- **Bug Reporting**: Reintroduced bug button feature for user issue reporting

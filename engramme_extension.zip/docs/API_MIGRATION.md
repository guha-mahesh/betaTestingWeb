# Engramme Assistant - API Migration

## Overview
The Engramme Assistant chrome extension has been successfully migrated from Google Sheets-based memory storage to the Engramme API, enabling real-time semantic memory search.

## Key Changes

### 1. Background Script (`background.js`)
- **Removed**: Google Sheets CSV parsing and fetching logic
- **Added**: API-based memory search that proxies requests from content scripts
- **API Endpoint**: `https://memorymachines-core-api-mvp-gateway-6v1lw71z.uc.gateway.dev/v1/memories/search`
- **Configuration**: Now uses API key stored in `chrome.storage.sync` instead of Sheet ID/GID
- **Character Limit**: Automatically truncates email content to 1000 characters (uses last 1000 for most recent context)

### 2. Content Script (`content.js`)
- **Removed**: Local `memory_dict` storage
- **Changed**: `findRelevantMemories()` now makes async API calls via background script
- **Added**: API configuration check before attempting memory searches
- **Improved**: Better error handling and user feedback when API is not configured
- **Loading States**: Shows "Searching memories..." while API call is in progress

### 3. Options UI (`options.html` & `options.js`)
- **Removed**: Google Sheet ID and Memory GID inputs
- **Added**: Engramme API key input field (password type for security)
- **Kept**: OpenAI API key field for email improvement feature
- **Simplified**: Status display now shows API configuration state
- **Validation**: Checks that Engramme API key starts with "sk_"

### 4. Manifest (`manifest.json`)
- **Updated**: Version bumped to 3.4.1
- **Changed**: Host permissions now point to Engramme API instead of Google Sheets
- **Permissions**: Same permissions maintained (storage, alarms)

## API Integration Details

### Memory Search Flow
1. User composes email in Gmail (50+ characters required)
2. Content script extracts email content (subject + body)
3. Content script sends `searchMemories` message to background script with text
4. Background script:
   - Gets API key from storage
   - Truncates text to 1000 characters (last 1000 for recent context)
   - Sends POST request to `/v1/memories/search` with:
     - `text`: Email content (max 1000 chars)
     - `top_k`: 3 (limit to 3 memories for clean UI)
   - Transforms API response to match component expectations
5. Background script returns memories to content script
6. Content script displays memories in overlay
7. When user clicks a memory, OpenAI improves the email incorporating that memory

### Memory Data Structure
The API returns memories with the following structure:
```javascript
{
  custom_id: string,
  content: {
    narrative: string,
    participants: string[],
    when: {
      event_start_time: string, // ISO timestamp or "unknown"
      event_end_time: string    // ISO timestamp or "unknown"
    },
    where: string,
    what_and_why: string,
    entities: string[],
    tags: string[]
  },
  score: number  // similarity score
}
```

`background.js` converts the structured `when` payload into a human-friendly string for display by formatting start/end timestamps (year-only, month-level, date, or time) and trimming shared prefixes so the second timestamp only shows what differs (e.g., `Monday, March 3, 2025 2 PM to 4 PM` renders as `Monday, March 3, 2025 2 PM to 4 PM`, while `Monday, March 3, 2025 2 PM` to `Monday, March 3, 2025 5 PM` renders as `Monday, March 3, 2025 2 PM to 5 PM`). Unknown end times are shown with a trailing arrow (e.g., `…→`).

### Authentication
- Uses `x-api-key` header for Engramme API authentication
- API key stored securely in Chrome sync storage
- Key format: `sk_...`

## Configuration

### For Users
1. Install/update the extension in Chrome
2. Click the extension icon to open settings
3. Enter your Engramme API key (obtain from engramme.ai)
4. (Optional) Enter OpenAI API key for AI-powered email improvements
5. Click "Save Settings"
6. Compose an email in Gmail to see relevant memories appear

### For Developers
- API base URL is defined in `background.js` as `API_BASE_URL`
- To change API endpoint, update this constant
- Top-k value (number of memories) can be adjusted in the `searchMemories` handler (currently 3)
- Debounce delay is set to 300ms in `content.js` to reduce API calls while typing

## Performance Considerations

1. **Debouncing**: 300ms delay before making API calls to avoid excessive requests while typing
2. **Character Limit**: Enforced 1000 character limit on API requests (uses last 1000 chars)
3. **Result Limit**: Limited to 3 memories per search to keep UI clean
4. **Caching**: No local caching - each search makes a fresh API call for real-time relevance
5. **Periodic Refresh**: Changed from 5 minutes to 30 minutes to reduce unnecessary checks

## Features Retained

✅ **Gmail Integration**: Works in both compose and email view modes
✅ **OpenAI Integration**: AI-powered email improvements when clicking memory cards
✅ **Smart Positioning**: Overlay positions itself intelligently based on compose window
✅ **Minimize/Collapse**: UI controls for managing overlay visibility
✅ **Visual Feedback**: Loading states, success/error messages

## Migration Notes

**Breaking Changes:**
- Old Google Sheets configuration will not work
- Users must configure Engramme API key to use the extension
- No backward compatibility with old storage format

**Benefits:**
- Real-time memory search powered by vector similarity
- No need to manually update Google Sheets
- Better relevance through semantic search
- Access to full user memory database
- More scalable architecture

## Testing Checklist

- [x] Extension loads without errors
- [x] Options page displays correctly with new API key field
- [x] Manifest updated with correct permissions
- [ ] API key can be saved and retrieved
- [ ] Gmail compose window detection works
- [ ] Memory search returns results from API
- [ ] Overlay displays memories correctly
- [ ] Error handling works when API key is missing
- [ ] Error handling works when API returns error
- [ ] Character limit is enforced (1000 chars to API)
- [ ] Debouncing prevents excessive API calls
- [ ] OpenAI email improvement still works
- [ ] Memory insertion into email works

## Future Enhancements

Potential improvements:
1. Add local caching to reduce API calls for recently searched content
2. Implement incremental loading for more memories (pagination)
3. Add user preferences for number of memories displayed
4. Add feedback mechanism for memory relevance
5. Support for custom API endpoints (self-hosted)
6. Better error messages with troubleshooting tips
7. Batch API requests when viewing multiple emails

## Troubleshooting

**Memories not appearing?**
- Make sure you've configured your Engramme API key in settings
- Check that you've typed 50+ characters in your email
- Click "Refresh Now" in extension settings
- Check Chrome DevTools Console for errors (F12)

**API errors?**
- Verify your API key is correct (should start with "sk_")
- Check your internet connection
- Ensure your API key has not expired
- Look at Chrome DevTools Console for detailed error messages

**Extension not loading?**
- Refresh Gmail page
- Reload extension in chrome://extensions/
- Check that all files are in the folder
- Look for errors in service worker console

## Privacy Note

- Email content is sent to Engramme API for memory search
- Email content is sent to OpenAI API for email improvements
- API keys are stored locally in Chrome sync storage
- No data is stored on external servers (except during API processing)
- All communication uses HTTPS

---

**Migration completed**: January 2025
**Version**: 3.4.1
**API**: Engramme v1

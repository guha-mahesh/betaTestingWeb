# Quick Start Guide - Engramme Assistant

## Installation (2 minutes)

1. **Open Chrome Extensions**:
   - Go to `chrome://extensions/` in your browser
   - Enable "Developer mode" (toggle in top-right corner)

2. **Load the Extension**:
   - Click "Load unpacked"
   - Navigate to and select the extension folder
   - The extension should now appear in your extensions list

3. **Verify Installation**:
   - Look for the "Engramme Assistant" icon in your Chrome toolbar
   - Click it to see the settings panel

## First Use

1. **Open Gmail**: Go to https://mail.google.com

2. **Compose an Email**:
   - Click the "Compose" button in Gmail
   - Start typing your email (needs 50+ characters)

3. **See Memories Appear**:
   - As you type, relevant memories will appear in the overlay on the left

4. **Click a Memory Card**:
   - Click any memory card
   - Watch as AI improves your email by incorporating the memory!

## What Happens When You Click a Memory

**Before (Old Behavior)**: Memory text was simply inserted into your email

**Now (AI-Powered)**:
1. Extension reads your current email draft
2. Sends draft + memory to OpenAI
3. AI rewrites the email to naturally incorporate the memory
4. Your email is replaced with the improved version

## Pre-Configured Settings

The extension comes ready to use with:

✅ **OpenAI API Key**: Pre-configured (you can change it in settings)
✅ **Google Sheet**: Connected to the memory database
✅ **Auto-refresh**: Updates memories every 5 minutes

## Testing It Out

Start composing an email (50+ characters) and relevant memories will appear based on the content of your message.

## Customization

### Change the AI Prompt

1. Open `content.js`
2. Go to lines **714-740**
3. Edit the `systemPrompt` to change AI behavior
4. Reload extension in Chrome

### Use Your Own OpenAI Key

1. Click the extension icon
2. Replace the API key in settings
3. Click "Save Settings"

### Connect Your Own Google Sheet

1. Click the extension icon
2. Enter your Sheet ID and GIDs
3. Click "Save Settings"

## Troubleshooting

**Memories not appearing?**
- Make sure you've typed 50+ characters
- Click "Refresh Now" in extension settings

**AI not working?**
- Check your internet connection
- Verify the OpenAI key in settings is valid
- Look at Chrome DevTools Console for errors (F12)

**Extension not loading?**
- Refresh Gmail page
- Reload extension in chrome://extensions/
- Check that all files are in the folder

## Privacy Note

- Your emails are sent to OpenAI's API for processing
- OpenAI API key is stored locally in Chrome
- Memory data is fetched from Google Sheets
- No data is stored on external servers (except OpenAI's processing)

## Support

For issues or questions:
- Check the [AI_INTEGRATION_README.md](AI_INTEGRATION_README.md) for detailed documentation
- Review Chrome DevTools console for errors
- Ensure all files are present in the extension folder

---

**Ready to go!** Open Gmail and start composing to see it in action. 🚀

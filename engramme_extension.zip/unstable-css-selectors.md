# Unstable CSS Selectors

This document tracks CSS selectors that are likely to break when sites update their UI. These are typically auto-generated class names that change periodically.

## Risk Levels

- **HIGH**: Obfuscated/minified class names that change frequently (weeks to months)
- **MEDIUM**: Class names that are somewhat readable but still generated
- **STABLE**: Semantic selectors, data attributes, or IDs unlikely to change

---

## Google Search (`google-search.js`)

### HIGH RISK - Will likely break

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `div.Y3BBE` | AI Overview container | `getAIOverview()` |
| `div.VwiC3b` | Search result snippet | `getSearchResults()` |
| `.lEBKkf` | Snippet class | `getSearchResults()` |
| `span.aCOpRe` | Alternative snippet | `getSearchResults()` |
| `.IsZvec` | Snippet container | `getSearchResults()` |
| `div.Ww4FFb` | Organic result container | `getSearchResults()` |
| `div.MjjYud` | Grouped results | `getSearchResults()` |
| `.DKV0Md` | Title class | `getSearchResults()` |
| `.yuRUbf` | Link wrapper | `getSearchResults()` |
| `span.CSkcDe` | PAA question text | `getVisiblePeopleAlsoAsk()` |
| `[jsname="Cpkphb"]` | PAA container | `getPeopleAlsoAsk()` |

### MEDIUM RISK

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `h3.LC20lb` | Search result title | `getVisibleTitles()` |
| `.related-question-pair` | PAA question container | `getVisiblePeopleAlsoAsk()` |
| `div.g` | Search result container | `getSearchResults()` |

### STABLE

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `input[name="q"]` | Search input | `getGoogleSearchContent()` |
| `div[data-attrid="wa:/description"]` | AI Overview (data attr) | `getAIOverview()` |
| `div[data-sncf]` | Snippet (data attr) | `getSearchResults()` |
| `div[data-content-feature]` | Content feature (data attr) | `getSearchResults()` |
| `div[data-hveid][lang]` | Result container (data attr) | `getSearchResults()` |
| `[data-initq]` | PAA container (data attr) | `getPeopleAlsoAsk()` |
| `[data-q]` | PAA question (data attr) | `getPeopleAlsoAsk()` |
| `div#rso` | Results container (ID) | `getSearchResults()` |
| `div#search` | Search container (ID) | `getSearchResults()` |
| `h3` | Title element | `getSearchResults()` |
| `.st` | Basic snippet (old but stable) | `getSearchResults()` |

---

## Google Docs (`scrapers.js`)

### HIGH RISK

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `.kix-paragraphrenderer` | Paragraph content | `getGoogleDocsContent()` |
| `.kix-appview-editor` | Editor container | `getGoogleDocsContent()` |

### STABLE

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `script` (DOCS_modelChunk) | Document data | `getGoogleDocsContent()` |

---

## Instagram (`scrapers.js`)

### HIGH RISK - Instagram changes frequently

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `._aa_c span` | Profile bio | `getInstagramContent()` |
| `._aacl._aaco._aacw._aad6._aade` | Bio alternative | `getInstagramContent()` |
| `._a9zs span` | Post caption | `getInstagramContent()` |
| `._a9zr span` | Caption alternative | `getInstagramContent()` |
| `.C4VMK span` | Caption/comment | `getInstagramContent()` |

### STABLE

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `article span` | Generic article content | `getInstagramContent()` |

---

## ChatGPT (`scrapers.js`)

### MEDIUM RISK

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `.group\/conversation-turn` | Message container | `getChatGPTContent()` |
| `.markdown` | Response content | `getChatGPTContent()` |
| `.whitespace-pre-wrap` | Text content | `getChatGPTContent()` |
| `.font-semibold` | Role indicator | `getChatGPTContent()` |
| `.text-xl` | Title | `getChatGPTContent()` |

### STABLE

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `[data-message-author-role]` | Message role (data attr) | `getChatGPTContent()` |
| `h1` | Title | `getChatGPTContent()` |

---

## Reddit (`scrapers.js`)

### HIGH RISK

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `._3xX726aBn29LDbsDtzr_6E` | Post content | `getRedditContent()` |
| `._1qeIAgB0cPwnLhDF9XSiJM` | Comment container | `getRedditContent()` |
| `._292iotee39Lmt0MkQZ2hPV` | Comment content | `getRedditContent()` |
| `.RichTextJSON-root` | Rich text content | `getRedditContent()` |

### MEDIUM RISK

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `.PostHeader__post-title-line` | Post title | `getRedditContent()` |
| `.Comment` | Comment element | `getRedditContent()` |
| `shreddit-app` | Main app (web component) | `getRedditContent()` |

### STABLE

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `[data-test-id="post-content"]` | Post content (data attr) | `getRedditContent()` |
| `[data-testid="comment"]` | Comment (data attr) | `getRedditContent()` |
| `[data-testid="comment-content"]` | Comment text (data attr) | `getRedditContent()` |
| `[data-click-id="text"]` | Text content (data attr) | `getRedditContent()` |
| `h1` | Post title | `getRedditContent()` |
| `main` | Main content | `getRedditContent()` |
| `#AppRouter-main-content` | Main content (ID) | `getRedditContent()` |

---

## Amazon (`scrapers.js`)

### MEDIUM RISK

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `.a-price-whole` | Price display | `getAmazonContent()` |
| `.a-price .a-offscreen` | Price (accessible) | `getAmazonContent()` |
| `.a-icon-alt` | Rating icon | `getAmazonContent()` |

### STABLE

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `#productTitle` | Product title (ID) | `getAmazonContent()` |
| `#title` | Title (ID) | `getAmazonContent()` |
| `#priceblock_ourprice` | Price (ID) | `getAmazonContent()` |
| `#priceblock_dealprice` | Deal price (ID) | `getAmazonContent()` |
| `#feature-bullets li` | Features (ID) | `getAmazonContent()` |
| `#featurebullets_feature_div li` | Features alt (ID) | `getAmazonContent()` |
| `#productDescription` | Description (ID) | `getAmazonContent()` |
| `#aplus` | A+ content (ID) | `getAmazonContent()` |
| `[data-hook="rating-out-of-text"]` | Rating (data attr) | `getAmazonContent()` |
| `[data-hook="review-body"]` | Review (data attr) | `getAmazonContent()` |
| `.review-text-content` | Review text | `getAmazonContent()` |

---

## Wikipedia (`scrapers.js`)

### STABLE (Wikipedia rarely changes)

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `h1.firstHeading` | Article title | `getWikipediaContent()` |
| `#firstHeading` | Title (ID) | `getWikipediaContent()` |
| `.mw-parser-output > p` | Paragraphs | `getWikipediaContent()` |
| `.mw-parser-output > h2` | Section headers | `getWikipediaContent()` |
| `.mw-parser-output > h3` | Subsection headers | `getWikipediaContent()` |
| `.infobox` | Infobox | `getWikipediaContent()` |
| `.infobox tr` | Infobox rows | `getWikipediaContent()` |
| `.infobox th` | Infobox labels | `getWikipediaContent()` |
| `.infobox td` | Infobox values | `getWikipediaContent()` |

---

## SF Chronicle (`sfchronicle.js`)

### STABLE (uses data attributes)

| Selector | Purpose | File Location |
|----------|---------|---------------|
| `a[data-link="native"]` | Article links | `getHomepageTitles()` |
| `a[cmp-ltrk="HP - Centerpiece"]` | Featured articles | `getHomepageTitles()` |
| `meta[name="sailthru.title"]` | Article title | `getArticleContent()` |
| `meta[name="author"]` | Author | `getArticleContent()` |
| `p[data-mrf-recirculation="Article - Paragraph links"]` | Article paragraphs | `getArticleContent()` |
| `h1` | Title element | `getArticleContent()` |
| `header` | Header element | `getArticleContent()` |
| `nav` | Navigation (to exclude) | `getHomepageTitles()` |

---

## Maintenance Notes

When extraction breaks on a site:

1. Open DevTools on the affected page
2. Inspect the element you're trying to scrape
3. Look for:
   - `data-*` attributes (most stable)
   - IDs (stable)
   - Semantic elements like `h1`, `article`, `main` (stable)
   - Readable class names (medium stability)
   - Obfuscated classes like `VwiC3b` (least stable)
4. Add new selectors to the fallback arrays
5. Update this document

## Last Updated

2025-01-07
